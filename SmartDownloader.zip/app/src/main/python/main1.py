import sys
import os
import re
import io
import json
import time
import base64
import shutil
import socket
import hashlib
import threading
import urllib.parse
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, unquote, quote, unquote_plus
from collections import defaultdict

from flask import (Flask, render_template_string, request, jsonify, session,
                   redirect, url_for, send_file, Response)
import requests
import yt_dlp
import qrcode
from PIL import Image, ImageFilter, ImageEnhance, ImageOps

app = Flask(__name__, static_folder=None)
app.secret_key = 'supersecretkey_downloader_2024_v2'

# ======================== EMBEDDED TEMPLATES ========================
INDEX_HTML = r'''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تسجيل الدخول - مركز التحميل</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
    background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
    min-height: 100vh; display: flex; align-items: center;
    justify-content: center; overflow: hidden; position: relative;
  }
  .particles { position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 0; }
  .particle { position: absolute; width: 4px; height: 4px; background: rgba(120,80,255,0.6); border-radius: 50%; animation: float linear infinite; }
  @keyframes float { 0%{transform:translateY(100vh) scale(0);opacity:0} 10%{opacity:1} 90%{opacity:1} 100%{transform:translateY(-100px) scale(1);opacity:0} }
  .login-card {
    background: rgba(255,255,255,0.05); backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.15); border-radius: 24px;
    padding: 50px 40px; width: 420px; max-width: 95vw; text-align: center;
    position: relative; z-index: 1; box-shadow: 0 25px 60px rgba(0,0,0,0.5);
    animation: slideUp 0.6s ease;
  }
  @keyframes slideUp { from{transform:translateY(40px);opacity:0} to{transform:translateY(0);opacity:1} }
  .logo { font-size: 64px; margin-bottom: 10px; animation: pulse 2s infinite; }
  @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.08)} }
  h1 { color: #fff; font-size: 26px; margin-bottom: 6px; background: linear-gradient(90deg,#a78bfa,#60a5fa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
  .subtitle { color: rgba(255,255,255,0.5); font-size: 14px; margin-bottom: 36px; }
  .form-group { margin-bottom: 20px; position: relative; }
  .form-group label { display: block; color: rgba(255,255,255,0.7); font-size: 14px; margin-bottom: 8px; text-align: right; }
  .form-group input { width: 100%; padding: 14px 18px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); border-radius: 12px; color: #fff; font-size: 18px; letter-spacing: 6px; text-align: center; transition: all 0.3s; direction: ltr; }
  .form-group input:focus { outline: none; border-color: #a78bfa; background: rgba(167,139,250,0.1); box-shadow: 0 0 0 3px rgba(167,139,250,0.2); }
  .form-group input::placeholder { letter-spacing: 2px; opacity: 0.4; }
  .btn-login { width: 100%; padding: 15px; background: linear-gradient(135deg,#7c3aed,#4f46e5); color: #fff; border: none; border-radius: 12px; font-size: 17px; cursor: pointer; transition: all 0.3s; font-family: inherit; font-weight: 600; box-shadow: 0 8px 20px rgba(124,58,237,0.4); }
  .btn-login:hover { transform: translateY(-2px); box-shadow: 0 12px 28px rgba(124,58,237,0.6); }
  .btn-login:active { transform: translateY(0); }
  .error-msg { background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.3); color: #fca5a5; border-radius: 10px; padding: 12px; margin-bottom: 20px; font-size: 14px; animation: shake 0.4s ease; }
  @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-8px)} 75%{transform:translateX(8px)} }
  .features { margin-top: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .feature-item { background: rgba(255,255,255,0.05); border-radius: 10px; padding: 12px 8px; color: rgba(255,255,255,0.6); font-size: 12px; }
  .feature-item span { display: block; font-size: 20px; margin-bottom: 4px; }
  .divider { border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 24px 0; }
  .hint { color: rgba(255,255,255,0.3); font-size: 12px; margin-top: 16px; }
</style>
</head>
<body>
<div class="particles" id="particles"></div>
<div class="login-card">
  <div class="logo">🚀</div>
  <h1>مركز التحميل الذكي</h1>
  <p class="subtitle">منصة متكاملة لتحميل الفيديوهات والملفات</p>
  {% if error %}<div class="error-msg">⚠️ {{ error }}</div>{% endif %}
  <form method="POST" action="/login">
    <div class="form-group">
      <label>أدخل رمز الدخول</label>
      <input type="password" name="code" placeholder="● ● ● ● ● ●" maxlength="10" autocomplete="off" autofocus required>
    </div>
    <button type="submit" class="btn-login">🔓 دخول</button>
  </form>
  <hr class="divider">
  <div class="features">
    <div class="feature-item"><span>🎬</span>تحميل فيديو</div>
    <div class="feature-item"><span>📁</span>تحميل ملفات</div>
    <div class="feature-item"><span>🔍</span>تحليل روابط</div>
    <div class="feature-item"><span>📊</span>إحصائيات</div>
  </div>
  <p class="hint">🔒 محمي بكلمة مرور</p>
</div>
<script>
  const container = document.getElementById('particles');
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `left:${Math.random()*100}%;animation-duration:${4+Math.random()*8}s;animation-delay:${Math.random()*6}s;width:${2+Math.random()*4}px;height:${2+Math.random()*4}px;background:hsl(${240+Math.random()*60},80%,65%)`;
    container.appendChild(p);
  }
</script>
</body>
</html>'''

OFFLINE_HTML = r'''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><title>غير متصل</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI',Arial,sans-serif;background:#0d0d1a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;direction:rtl}
.box{text-align:center;padding:40px}.box .icon{font-size:72px;margin-bottom:20px}.box h1{font-size:24px;margin-bottom:10px}.box p{color:#64748b;margin-bottom:24px}
.btn{padding:12px 24px;background:#7c3aed;color:#fff;border:none;border-radius:10px;font-size:14px;cursor:pointer;font-family:inherit}
</style></head>
<body><div class="box"><div class="icon">📶</div><h1>أنت غير متصل بالإنترنت</h1><p>تحقق من اتصالك ثم حاول مجدداً</p><button class="btn" onclick="location.reload()">🔄 إعادة المحاولة</button></div></body>
</html>'''

DASHBOARD_HTML = r'''<!DOCTYPE html>
<html lang="ar" dir="rtl" id="html-root">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#7c3aed">
<meta name="description" content="مركز التحميل الذكي - منصة متكاملة لتحميل الفيديوهات والملفات">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="التحميل الذكي">
<meta name="mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/static/icons/icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/static/icons/icon-48x48.png">
<link rel="icon" type="image/png" sizes="192x192" href="/static/icons/icon-192x192.png">
<title>مركز التحميل الذكي</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#0d0d1a;--card:#13131f;--card2:#1a1a2e;--border:rgba(255,255,255,0.07);
  --accent:#7c3aed;--accent2:#4f46e5;
  --blue:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--pink:#ec4899;
  --text:#e2e8f0;--muted:#64748b;--sidebar:240px;--fs:14px;
}
body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;direction:rtl;font-size:var(--fs);transition:font-size .2s}

/* SIDEBAR */
.sidebar{position:fixed;top:0;right:0;width:var(--sidebar);height:100vh;background:var(--card);border-left:1px solid var(--border);padding:16px 12px;display:flex;flex-direction:column;gap:3px;z-index:100;overflow-y:auto;transition:transform .3s}
.sidebar::-webkit-scrollbar{width:3px}.sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:3px}
.logo-area{text-align:center;padding:8px 0 14px;border-bottom:1px solid var(--border);margin-bottom:6px}
.logo-area img.app-icon{width:52px;height:52px;border-radius:14px;box-shadow:0 4px 16px rgba(124,58,237,0.4)}
.logo-area h2{font-size:13px;color:var(--accent);margin-top:6px;font-weight:700}
.logo-area small{color:var(--muted);font-size:10px;display:block;margin-top:2px}
.nav-group-label{font-size:9px;color:var(--muted);padding:8px 12px 3px;text-transform:uppercase;letter-spacing:1px;opacity:.55}
.nav-item{display:flex;align-items:center;gap:9px;padding:9px 12px;border-radius:10px;cursor:pointer;color:var(--muted);transition:all .15s;font-size:.85em;background:transparent;border:none;width:100%;text-align:right;font-family:inherit}
.nav-item:hover{background:rgba(124,58,237,0.1);color:var(--text)}
.nav-item.active{background:rgba(124,58,237,0.18);color:#a78bfa;font-weight:600}
.nav-item .ni{font-size:15px;min-width:20px;text-align:center}
.nav-divider{height:1px;background:var(--border);margin:5px 0}
.logout-link{color:#fca5a5!important;text-decoration:none}
.logout-link:hover{background:rgba(239,68,68,0.1)!important;color:#f87171!important}

/* MAIN */
.main{margin-right:var(--sidebar);padding:20px;min-height:100vh;transition:margin .3s}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:10px}
.topbar h1{font-size:1.3em;color:#fff;font-weight:700}
.topbar-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:.78em;font-weight:600}
.badge-green{background:rgba(16,185,129,0.14);color:#34d399}
.badge-blue{background:rgba(59,130,246,0.14);color:#93c5fd}
.badge-purple{background:rgba(124,58,237,0.14);color:#a78bfa}

/* CARDS */
.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:18px;margin-bottom:14px}
.card-title{font-size:1em;font-weight:600;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:7px}
.card-subtitle{font-size:.78em;color:var(--muted);margin-right:auto;font-weight:400}

/* STATS */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;transition:transform .2s,box-shadow .2s}
.stat-card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.3)}
.stat-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px}
.stat-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px}
.stat-value{font-size:1.7em;font-weight:700;color:#fff;line-height:1}
.stat-label{color:var(--muted);font-size:.78em;margin-top:3px}

/* INPUTS */
.input-row{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
.inp{flex:1;padding:10px 13px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;color:var(--text);font-size:.9em;font-family:inherit;transition:border-color .2s;min-width:80px}
.inp:focus{outline:none;border-color:var(--accent);background:rgba(124,58,237,0.05)}
.inp::placeholder{color:var(--muted)}
.inp[dir="ltr"]{direction:ltr}
textarea.inp{resize:vertical;min-height:80px}
select.inp{cursor:pointer}
select.inp option{background:#1a1a2e}

/* BUTTONS */
.btn{padding:10px 16px;border:none;border-radius:10px;font-size:.87em;cursor:pointer;font-family:inherit;font-weight:600;transition:all .15s;white-space:nowrap;display:inline-flex;align-items:center;gap:5px}
.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;box-shadow:0 4px 12px rgba(124,58,237,.25)}
.btn-primary:hover{opacity:.9;transform:translateY(-1px)}
.btn-success{background:linear-gradient(135deg,#059669,var(--green));color:#fff}
.btn-info{background:linear-gradient(135deg,#0ea5e9,var(--blue));color:#fff}
.btn-warning{background:linear-gradient(135deg,#d97706,var(--yellow));color:#fff}
.btn-danger{background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.2)}
.btn-danger:hover{background:rgba(239,68,68,0.2)}
.btn-ghost{background:rgba(255,255,255,0.05);color:var(--text);border:1px solid var(--border)}
.btn-ghost:hover{background:rgba(255,255,255,0.1)}
.btn-maps{background:linear-gradient(135deg,#1a73e8,#0d47a1);color:#fff}
.btn-sm{padding:6px 11px;font-size:.8em;border-radius:8px}
.btn:disabled{opacity:.4;cursor:not-allowed;transform:none!important}

/* SECTIONS */
.section{display:none}
.section.active{display:block;animation:fadeIn .2s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}

/* PROGRESS */
.progress-wrap{display:none;margin-top:12px}
.progress-wrap.show{display:block}
.progress-meta{display:flex;justify-content:space-between;font-size:.8em;color:var(--muted);margin-bottom:5px}
.progress-bar{height:7px;background:rgba(255,255,255,0.07);border-radius:7px;overflow:hidden}
.progress-fill{height:100%;border-radius:7px;background:linear-gradient(90deg,var(--accent),var(--blue));transition:width .4s ease;width:0}

/* STATUS */
.status-msg{display:none;padding:10px 13px;border-radius:10px;font-size:.87em;margin-top:10px;line-height:1.5}
.status-msg.show{display:block}
.status-success{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);color:#34d399}
.status-error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#fca5a5}
.status-info{background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.2);color:#93c5fd}
.status-warn{background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.2);color:#fcd34d}

/* VIDEO INFO */
.vid-info-box{display:none;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;padding:14px;margin-top:12px;gap:12px}
.vid-info-box.show{display:flex}
.vid-thumb{width:120px;min-width:120px;height:75px;border-radius:8px;object-fit:cover;background:#1e1e30}
.vid-meta-tags{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px}
.meta-tag{background:rgba(255,255,255,0.07);border-radius:5px;padding:2px 7px;font-size:.75em;color:var(--muted)}

/* RESULT GRID */
.result-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
.result-item{background:rgba(255,255,255,0.03);border-radius:9px;padding:10px 12px;border:1px solid var(--border)}
.result-item label{color:var(--muted);font-size:.72em;display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.4px}
.result-item span{color:#fff;font-size:.87em;direction:ltr;word-break:break-all;display:block}
.result-item.ok span{color:#34d399}
.result-item.warn span{color:#fca5a5}

/* TABLE */
.data-table{width:100%;border-collapse:collapse}
.data-table th,.data-table td{padding:10px 13px;text-align:right;border-bottom:1px solid var(--border);font-size:.82em}
.data-table th{color:var(--muted);font-weight:500;font-size:.75em;text-transform:uppercase;letter-spacing:.4px}
.data-table tr:hover td{background:rgba(255,255,255,0.02)}
.data-table tbody tr:last-child td{border-bottom:none}
.type-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 7px;border-radius:5px;font-size:.77em}
.tb-video{background:rgba(124,58,237,.15);color:#a78bfa}
.tb-file{background:rgba(59,130,246,.15);color:#93c5fd}

/* HISTORY */
.history-list{display:flex;flex-direction:column;gap:7px;max-height:320px;overflow-y:auto}
.hist-item{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,0.03);border-radius:9px;padding:10px 12px;border:1px solid var(--border)}
.hist-item:hover{background:rgba(255,255,255,0.05)}
.hist-icon{font-size:20px;min-width:28px;text-align:center}
.hist-info{flex:1;min-width:0}
.hist-name{color:#fff;font-size:.82em;direction:ltr;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hist-meta{color:var(--muted);font-size:.72em;margin-top:1px}
.hist-badge{font-size:.72em;padding:2px 7px;border-radius:5px;background:rgba(124,58,237,.15);color:#a78bfa;white-space:nowrap}

/* PLATFORMS */
.platforms-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:9px}
.platform-card{background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;padding:12px 8px;text-align:center;font-size:.82em;color:var(--muted);transition:all .2s}
.platform-card:hover{background:rgba(124,58,237,.08);color:#a78bfa;border-color:rgba(124,58,237,.2);transform:translateY(-2px)}
.platform-card .pc-icon{font-size:20px;display:block;margin-bottom:5px}

/* TOOLS */
.tools-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}

/* NOTES */
.notes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}
.note-card{border-radius:12px;padding:14px;position:relative;min-height:110px;display:flex;flex-direction:column}
.note-card h4{font-size:.9em;font-weight:600;color:#fff;margin-bottom:6px}
.note-card p{font-size:.82em;color:rgba(255,255,255,.7);flex:1;line-height:1.6;word-break:break-word}
.note-card .note-footer{display:flex;justify-content:space-between;align-items:center;margin-top:8px;font-size:.72em;opacity:.6}
.note-del{position:absolute;top:8px;left:8px;background:rgba(0,0,0,.35);border:none;color:#fff;width:22px;height:22px;border-radius:6px;cursor:pointer;font-size:11px;display:flex;align-items:center;justify-content:center}

/* SETTINGS */
.settings-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.setting-item{display:flex;align-items:center;justify-content:space-between;padding:12px;background:rgba(255,255,255,0.03);border-radius:10px;border:1px solid var(--border);gap:10px}
.setting-label{font-size:.9em;color:var(--text)}
.setting-desc{font-size:.75em;color:var(--muted);margin-top:2px}
.toggle{position:relative;width:44px;height:23px;min-width:44px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0}
.toggle-slider{position:absolute;cursor:pointer;inset:0;background:rgba(255,255,255,.1);border-radius:23px;transition:.3s}
.toggle-slider:before{position:absolute;content:"";height:17px;width:17px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s}
.toggle input:checked+.toggle-slider{background:var(--accent)}
.toggle input:checked+.toggle-slider:before{transform:translateX(21px)}

/* RANGE SLIDER */
.range-wrap{display:flex;align-items:center;gap:10px;flex:1}
input[type=range]{-webkit-appearance:none;width:100%;height:5px;border-radius:5px;background:rgba(255,255,255,.12);outline:none}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:var(--accent);cursor:pointer}
input[type=range]::-moz-range-thumb{width:16px;height:16px;border-radius:50%;background:var(--accent);border:none;cursor:pointer}

/* PING */
.ping-result{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:7px;font-size:.8em;font-weight:600}
.ping-ok{background:rgba(16,185,129,.15);color:#34d399}
.ping-fail{background:rgba(239,68,68,.15);color:#fca5a5}

/* LOADER */
.loader{display:inline-block;width:15px;height:15px;border:2px solid rgba(255,255,255,.2);border-top-color:#a78bfa;border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle}
@keyframes spin{to{transform:rotate(360deg)}}

/* HASH */
.hash-result{display:flex;flex-direction:column;gap:7px;margin-top:12px}
.hash-row{background:rgba(255,255,255,0.03);border-radius:8px;padding:9px 11px;border:1px solid var(--border)}
.hash-label{font-size:.72em;color:var(--muted);margin-bottom:3px;font-weight:600}
.hash-val{font-size:.8em;color:#a78bfa;direction:ltr;word-break:break-all;font-family:monospace;cursor:pointer}
.hash-val:hover{color:#c4b5fd}

/* TWO COL */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:14px}

/* DISK BAR */
.disk-bar{height:10px;background:rgba(255,255,255,.07);border-radius:8px;overflow:hidden;margin-top:7px}
.disk-fill{height:100%;border-radius:8px;background:linear-gradient(90deg,var(--accent),var(--blue));transition:width 1s}

/* ACTIVE DL */
.dl-item{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:9px;padding:11px 13px;margin-bottom:7px}
.dl-item-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:5px}
.dl-name{font-size:.82em;color:#fff;direction:ltr;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:65%}
.dl-status{font-size:.77em;color:var(--muted)}

/* EMPTY */
.empty{text-align:center;padding:36px 20px;color:var(--muted)}
.empty .ei{font-size:40px;margin-bottom:10px;opacity:.4}

/* MAPS BTN */
.maps-link{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;background:linear-gradient(135deg,#1a73e8,#0d47a1);color:#fff!important;border-radius:8px;font-size:.82em;font-weight:600;text-decoration:none;margin-top:8px}
.maps-link:hover{opacity:.88}
.coords-box{background:rgba(26,115,232,.08);border:1px solid rgba(26,115,232,.2);border-radius:10px;padding:12px;margin-top:10px}

/* COLOR INPUT */
input[type=color]{-webkit-appearance:none;border:none;padding:0;width:34px;height:34px;border-radius:8px;cursor:pointer;background:none}
input[type=color]::-webkit-color-swatch-wrapper{padding:0;border-radius:8px}
input[type=color]::-webkit-color-swatch{border:none;border-radius:8px}

/* INSTALL BTN */
.install-btn{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;border:none;border-radius:9px;padding:8px 12px;font-size:.82em;font-weight:600;cursor:pointer;width:100%;font-family:inherit;display:flex;align-items:center;gap:7px;justify-content:center;margin-top:6px;transition:opacity .2s}
.install-btn:hover{opacity:.9}

/* LANG BTN */
.lang-toggle{background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:8px;padding:6px 10px;font-size:.78em;color:var(--text);cursor:pointer;font-family:inherit;transition:all .2s}
.lang-toggle:hover{background:rgba(255,255,255,.1)}

/* IMG */
.img-preview{max-width:100%;max-height:260px;border-radius:10px;border:1px solid var(--border);display:block;margin:8px auto}
.img-ops{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}

/* RESPONSIVE */
@media(max-width:1100px){.stats-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:900px){
  :root{--sidebar:52px}
  .sidebar{padding:10px 5px}
  .logo-area{padding:6px 0 10px}
  .logo-area h2,.logo-area small,.nav-group-label,.nav-item span:not(.ni),.sidebar-extras{display:none}
  .nav-item{padding:11px;justify-content:center}
  .logo-area img.app-icon{width:36px;height:36px}
}
@media(max-width:640px){
  :root{--sidebar:0px}
  .sidebar{transform:translateX(100%);width:230px;padding:16px 12px}
  .sidebar.open{transform:translateX(0)}
  .sidebar.open .logo-area h2,.sidebar.open .logo-area small,.sidebar.open .nav-group-label,.sidebar.open .nav-item span:not(.ni),.sidebar.open .sidebar-extras{display:block!important}
  .sidebar.open .logo-area img.app-icon{width:52px;height:52px}
  .sidebar.open .nav-item{padding:9px 12px;justify-content:flex-start}
  .main{margin-right:0!important;padding:12px}
  .stats-grid{grid-template-columns:repeat(2,1fr);gap:8px}
  .result-grid,.tools-grid,.settings-grid,.two-col{grid-template-columns:1fr}
  .vid-info-box.show{flex-direction:column}
  .vid-thumb{width:100%;min-width:unset;height:150px}
  .hamburger{display:flex!important}
}
.hamburger{display:none;position:fixed;top:10px;left:10px;z-index:200;background:var(--card);border:1px solid var(--border);border-radius:10px;padding:8px;cursor:pointer;flex-direction:column;gap:4px;box-shadow:0 4px 12px rgba(0,0,0,.3)}
.hamburger span{display:block;width:18px;height:2px;background:#fff;border-radius:2px}

.main::-webkit-scrollbar{width:5px}
.main::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:4px}
</style>
</head>
<body>

<div class="hamburger" id="hamburger" onclick="toggleSidebar()">
  <span></span><span></span><span></span>
</div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
  <div class="logo-area">
    <img class="app-icon" src="/static/icons/icon-192x192.png" alt="icon">
    <h2 data-i18n="app_name">مركز التحميل</h2>
    <small id="clock-small"></small>
  </div>

  <span class="nav-group-label" data-i18n="nav_main">الرئيسي</span>
  <button class="nav-item active" onclick="go('home',this)"><span class="ni">🏠</span><span data-i18n="nav_home">الرئيسية</span></button>
  <button class="nav-item" onclick="go('downloads',this)"><span class="ni">⚡</span><span data-i18n="nav_active">النشطة</span></button>

  <span class="nav-group-label" data-i18n="nav_download">التحميل</span>
  <button class="nav-item" onclick="go('video',this)"><span class="ni">🎬</span><span data-i18n="nav_video">تحميل فيديو</span></button>
  <button class="nav-item" onclick="go('file',this)"><span class="ni">📁</span><span data-i18n="nav_file">تحميل ملف</span></button>
  <button class="nav-item" onclick="go('files-list',this)"><span class="ni">💾</span><span data-i18n="nav_myfiles">ملفاتي</span></button>

  <span class="nav-group-label" data-i18n="nav_tools">أدوات</span>
  <button class="nav-item" onclick="go('analyze',this)"><span class="ni">🔍</span><span data-i18n="nav_analyze">تحليل رابط</span></button>
  <button class="nav-item" onclick="go('qrcode',this)"><span class="ni">📷</span><span data-i18n="nav_qr">باركود QR</span></button>
  <button class="nav-item" onclick="go('text-tools',this)"><span class="ni">🔐</span><span data-i18n="nav_text">أدوات النصوص</span></button>
  <button class="nav-item" onclick="go('image-tools',this)"><span class="ni">🖼</span><span data-i18n="nav_img">أدوات الصور</span></button>
  <button class="nav-item" onclick="go('network',this)"><span class="ni">🌐</span><span data-i18n="nav_net">أدوات الشبكة</span></button>

  <span class="nav-group-label">⭐ مميز</span>
  <button class="nav-item" onclick="go('weather',this)"><span class="ni">🌦</span><span>الطقس والعالم</span></button>
  <button class="nav-item" onclick="go('currency',this)"><span class="ni">💱</span><span>محوّل العملات</span></button>
  <button class="nav-item" onclick="go('batch',this)"><span class="ni">⬇</span><span>تحميل متعدد</span></button>
  <button class="nav-item" onclick="go('shortener',this)"><span class="ni">🔗</span><span>مختصر الروابط</span></button>
  <button class="nav-item" onclick="go('adv-tools',this)"><span class="ni">🧰</span><span>أدوات متقدمة</span></button>

  <span class="nav-group-label" data-i18n="nav_other">أخرى</span>
  <button class="nav-item" onclick="go('notes',this)"><span class="ni">📝</span><span data-i18n="nav_notes">ملاحظات</span></button>
  <button class="nav-item" onclick="go('platforms',this)"><span class="ni">📡</span><span data-i18n="nav_platforms">المنصات</span></button>
  <button class="nav-item" onclick="go('stats',this)"><span class="ni">📊</span><span data-i18n="nav_stats">الإحصائيات</span></button>
  <button class="nav-item" onclick="go('settings',this)"><span class="ni">⚙️</span><span data-i18n="nav_settings">الإعدادات</span></button>

  <div class="nav-divider"></div>

  <div class="sidebar-extras" style="display:flex;flex-direction:column;gap:6px;padding:4px 0">
    <button id="install-btn" class="install-btn" style="display:none" onclick="installPWA()">
      📲 <span data-i18n="install_app">تثبيت التطبيق</span>
    </button>
    <div style="display:flex;gap:6px">
      <button class="lang-toggle" style="flex:1" onclick="toggleLang()" id="lang-btn">EN</button>
      <button class="lang-toggle" style="flex:1" onclick="go('settings',document.querySelectorAll('.nav-item')[13])">⚙</button>
    </div>
  </div>

  <div class="nav-divider"></div>
  <a href="/logout" class="nav-item logout-link"><span class="ni">🚪</span><span data-i18n="nav_logout">خروج</span></a>
</div>

<!-- MAIN -->
<div class="main" id="main">
  <div class="topbar">
    <h1 id="page-title" data-i18n="nav_home">الرئيسية</h1>
    <div class="topbar-right">
      <span class="badge badge-green" id="dl-badge" style="display:none">⬇ <span id="dl-count">0</span></span>
      <span class="badge badge-green">● <span data-i18n="status_running">مشغّل</span></span>
      <span style="color:var(--muted);font-size:.8em" id="clock"></span>
    </div>
  </div>

  <!-- HOME -->
  <div class="section active" id="sec-home">
    <div class="stats-grid">
      <div class="stat-card" style="border-top:3px solid var(--accent)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(124,58,237,.15)">📥</div></div>
        <div class="stat-value" id="h-total">0</div>
        <div class="stat-label" data-i18n="stat_total">إجمالي التحميلات</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--blue)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(59,130,246,.15)">🎬</div></div>
        <div class="stat-value" id="h-videos">0</div>
        <div class="stat-label" data-i18n="stat_videos">فيديوهات</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--green)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(16,185,129,.15)">📁</div></div>
        <div class="stat-value" id="h-files">0</div>
        <div class="stat-label" data-i18n="stat_files">ملفات</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--yellow)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(245,158,11,.15)">💾</div></div>
        <div class="stat-value" id="h-size">0 B</div>
        <div class="stat-label" data-i18n="stat_size">حجم التحميلات</div>
      </div>
    </div>
    <div class="two-col">
      <div class="card">
        <div class="card-title">⚡ <span data-i18n="quick_start">بدء سريع</span></div>
        <div class="input-row">
          <input class="inp" dir="ltr" id="quick-url" placeholder="https://...">
          <button class="btn btn-primary btn-sm" onclick="quickAction()" data-i18n="btn_analyze">تحليل</button>
          <button class="btn btn-ghost btn-sm" onclick="pasteClipboard('quick-url')" title="لصق">📋</button>
        </div>
        <div id="quick-result"></div>
      </div>
      <div class="card">
        <div class="card-title">💿 <span data-i18n="disk_space">مساحة القرص</span></div>
        <div id="disk-info"><span class="loader"></span></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">📋 <span data-i18n="recent_dl">آخر التحميلات</span></div>
      <div class="history-list" id="hist-home">
        <div class="empty"><div class="ei">📂</div><p data-i18n="no_downloads">لا توجد تحميلات بعد</p></div>
      </div>
    </div>
  </div>

  <!-- ACTIVE DOWNLOADS -->
  <div class="section" id="sec-downloads">
    <div class="card">
      <div class="card-title">⚡ <span data-i18n="active_dl">التحميلات النشطة</span> <span class="card-subtitle" id="active-count">0</span></div>
      <div id="active-list"><div class="empty"><div class="ei">✅</div><p data-i18n="no_active">لا توجد تحميلات جارية</p></div></div>
    </div>
    <div class="card">
      <div class="card-title">📋 <span data-i18n="all_history">سجل التحميلات</span></div>
      <div class="history-list" id="hist-all"><div class="empty"><div class="ei">📂</div><p data-i18n="no_history">لا يوجد سجل</p></div></div>
    </div>
  </div>

  <!-- VIDEO -->
  <div class="section" id="sec-video">
    <div class="card">
      <div class="card-title">🎬 <span data-i18n="video_title">تحميل فيديو من أي منصة</span></div>
      <div class="input-row">
        <input class="inp" dir="ltr" id="vid-url" placeholder="https://youtube.com/watch?v=...">
        <button class="btn btn-ghost btn-sm" onclick="pasteClipboard('vid-url')">📋</button>
        <button class="btn btn-info" onclick="fetchVideoInfo()" id="vid-fetch-btn" data-i18n="btn_fetch">جلب المعلومات</button>
      </div>
      <div class="vid-info-box" id="vid-info">
        <img id="vid-thumb" class="vid-thumb" src="" alt="">
        <div style="flex:1">
          <h3 id="vid-title" style="font-size:.95em;color:#fff;margin-bottom:7px"></h3>
          <div class="vid-meta-tags" id="vid-meta"></div>
          <p id="vid-desc" style="font-size:.78em;color:var(--muted);margin-bottom:10px;line-height:1.5;max-height:36px;overflow:hidden"></p>
          <div class="input-row" style="margin-bottom:0">
            <select class="inp" id="vid-quality"><option>720p</option></select>
            <button class="btn btn-success" onclick="startVideoDownload()">⬇ <span data-i18n="btn_download">تحميل</span></button>
          </div>
        </div>
      </div>
      <div class="progress-wrap" id="vid-prog">
        <div class="progress-meta"><span id="vid-st">...</span><span id="vid-pct-txt">0%</span></div>
        <div class="progress-bar"><div class="progress-fill" id="vid-fill"></div></div>
        <div style="display:flex;gap:12px;margin-top:4px">
          <span style="font-size:.78em;color:var(--muted)" id="vid-speed"></span>
          <span style="font-size:.78em;color:var(--muted)" id="vid-eta"></span>
        </div>
      </div>
      <div class="status-msg" id="vid-msg"></div>
    </div>
    <div class="card">
      <div class="card-title">🌐 <span data-i18n="supported_platforms">منصات الفيديو المدعومة</span></div>
      <div class="platforms-grid" id="vid-platforms"></div>
    </div>
  </div>

  <!-- FILE -->
  <div class="section" id="sec-file">
    <div class="card">
      <div class="card-title">📁 <span data-i18n="file_title">تحميل ملف برابط مباشر</span></div>
      <div class="input-row">
        <input class="inp" dir="ltr" id="file-url" placeholder="https://example.com/file.zip">
        <button class="btn btn-ghost btn-sm" onclick="pasteClipboard('file-url')">📋</button>
      </div>
      <div class="input-row">
        <input class="inp" id="file-name" placeholder="اسم الملف (اختياري)">
        <button class="btn btn-primary" onclick="startFileDownload()">⬇ <span data-i18n="btn_download">تحميل</span></button>
      </div>
      <div class="progress-wrap" id="file-prog">
        <div class="progress-meta"><span id="file-st">...</span><span id="file-pct-txt">0%</span></div>
        <div class="progress-bar"><div class="progress-fill" id="file-fill"></div></div>
        <div style="font-size:.78em;color:var(--muted);margin-top:3px" id="file-size-info"></div>
      </div>
      <div class="status-msg" id="file-msg"></div>
    </div>
  </div>

  <!-- FILES LIST -->
  <div class="section" id="sec-files-list">
    <div class="card">
      <div class="card-title">💾 <span data-i18n="my_files">ملفاتي</span> <span class="card-subtitle" id="files-count"></span></div>
      <div class="input-row" style="margin-bottom:10px;flex-wrap:wrap">
        <input class="inp" id="file-search" placeholder="🔍 بحث..." oninput="loadFiles()">
        <select class="inp" style="max-width:130px" id="file-sort" onchange="loadFiles()">
          <option value="date">التاريخ</option>
          <option value="size">الحجم</option>
          <option value="name">الاسم</option>
        </select>
        <button class="btn btn-info btn-sm" onclick="loadFiles()">🔄</button>
        <button class="btn btn-danger btn-sm" id="bulk-del-btn" style="display:none" onclick="bulkDelete()">🗑 حذف</button>
      </div>
      <div id="files-container"><div class="empty"><div class="ei">📂</div><p data-i18n="no_files">لا توجد ملفات</p></div></div>
    </div>
  </div>

  <!-- ANALYZE -->
  <div class="section" id="sec-analyze">
    <div class="card">
      <div class="card-title">🔍 <span data-i18n="analyze_title">تحليل رابط شامل</span></div>
      <div class="input-row">
        <input class="inp" dir="ltr" id="analyze-url" placeholder="https://example.com">
        <button class="btn btn-ghost btn-sm" onclick="pasteClipboard('analyze-url')">📋</button>
        <button class="btn btn-info" onclick="analyzeLink()" data-i18n="btn_analyze">تحليل</button>
      </div>
      <div id="analyze-result" style="display:none"><div class="result-grid" id="result-grid"></div></div>
      <div class="status-msg" id="analyze-msg"></div>
    </div>
  </div>

  <!-- QR CODE -->
  <div class="section" id="sec-qrcode">
    <div class="two-col">
      <div class="card">
        <div class="card-title">✨ <span data-i18n="qr_gen">إنشاء باركود QR</span></div>
        <textarea class="inp" id="qr-text" rows="3" placeholder="أدخل نص أو رابط..." style="width:100%;margin-bottom:10px;direction:rtl"></textarea>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:12px">
          <div><div style="font-size:.75em;color:var(--muted);margin-bottom:5px" data-i18n="qr_color">لون الباركود</div><input type="color" id="qr-color" value="#000000" style="width:100%"></div>
          <div><div style="font-size:.75em;color:var(--muted);margin-bottom:5px" data-i18n="qr_bg">لون الخلفية</div><input type="color" id="qr-bg" value="#ffffff" style="width:100%"></div>
          <div><div style="font-size:.75em;color:var(--muted);margin-bottom:5px" data-i18n="qr_size">الحجم</div>
            <select class="inp" id="qr-size"><option value="6">صغير</option><option value="10" selected>متوسط</option><option value="15">كبير</option><option value="20">كبير جداً</option></select>
          </div>
        </div>
        <button class="btn btn-primary" style="width:100%" onclick="generateQR()">🔲 <span data-i18n="qr_create">إنشاء الباركود</span></button>
        <div id="qr-gen-result" style="text-align:center;display:none;margin-top:12px">
          <img id="qr-img" src="" style="max-width:220px;border-radius:10px;border:4px solid var(--border);background:#fff;padding:7px">
          <br>
          <a id="qr-dl" href="#" download="qrcode.png" class="btn btn-success btn-sm" style="margin-top:8px;display:inline-flex">⬇ <span data-i18n="btn_download">تحميل</span></a>
        </div>
        <div class="status-msg" id="qr-gen-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">🔍 <span data-i18n="qr_read">قراءة باركود QR</span></div>
        <div id="qr-drop" onclick="document.getElementById('qr-file').click()"
          style="border:2px dashed var(--border);border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:all .2s;margin-bottom:10px">
          <div style="font-size:32px;margin-bottom:7px">📷</div>
          <div style="color:var(--muted);font-size:.87em" data-i18n="qr_drop">اضغط لاختيار صورة أو اسحبها</div>
          <div style="color:var(--muted);font-size:.72em;margin-top:3px">PNG, JPG, WEBP</div>
        </div>
        <input type="file" id="qr-file" accept="image/*" style="display:none" onchange="readQR(this)">
        <div id="qr-read-preview" style="display:none;text-align:center;margin-bottom:10px">
          <img id="qr-prev-img" src="" style="max-width:160px;border-radius:8px">
        </div>
        <div id="qr-read-result" style="display:none">
          <div style="background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.2);border-radius:10px;padding:11px">
            <div style="color:var(--muted);font-size:.72em;margin-bottom:3px">المحتوى:</div>
            <div id="qr-decoded" style="color:#34d399;font-size:.87em;word-break:break-all;direction:ltr;font-family:monospace"></div>
            <div style="display:flex;gap:7px;margin-top:9px;flex-wrap:wrap">
              <button class="btn btn-info btn-sm" onclick="copyText(qrResult)">📋 نسخ</button>
              <button id="qr-open-btn" class="btn btn-primary btn-sm" style="display:none" onclick="window.open(qrResult,'_blank')">🔗 فتح</button>
            </div>
          </div>
        </div>
        <div class="status-msg" id="qr-read-msg"></div>
        <canvas id="qr-canvas" style="display:none"></canvas>
      </div>
    </div>
  </div>

  <!-- TEXT TOOLS -->
  <div class="section" id="sec-text-tools">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🔐 <span data-i18n="encode_title">تشفير / فك تشفير</span></div>
        <textarea class="inp" id="enc-input" rows="4" placeholder="النص هنا..." style="width:100%;margin-bottom:10px;direction:ltr"></textarea>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
          <button class="btn btn-primary btn-sm" onclick="encode('b64_encode')">Base64 ↑</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('b64_decode')">Base64 ↓</button>
          <button class="btn btn-info btn-sm" onclick="encode('url_encode')">URL ↑</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('url_decode')">URL ↓</button>
          <button class="btn btn-warning btn-sm" onclick="encode('hex_encode')">HEX ↑</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('hex_decode')">HEX ↓</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('binary')">Binary</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('reverse')">عكس</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('upper')">UPPER</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('lower')">lower</button>
          <button class="btn btn-ghost btn-sm" onclick="encode('count')">إحصاء</button>
        </div>
        <div id="enc-result" style="display:none">
          <div id="enc-output" style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;padding:9px 11px;font-size:.8em;color:#a78bfa;direction:ltr;word-break:break-all;font-family:monospace;max-height:120px;overflow-y:auto"></div>
          <button class="btn btn-ghost btn-sm" style="margin-top:7px" onclick="copyText(document.getElementById('enc-output').textContent)">📋 نسخ</button>
        </div>
        <div class="status-msg" id="enc-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">🔑 <span data-i18n="hash_title">مولّد الهاش</span></div>
        <textarea class="inp" id="hash-input" rows="4" placeholder="النص لحساب الهاش..." style="width:100%;margin-bottom:10px;direction:ltr"></textarea>
        <button class="btn btn-primary" style="width:100%;margin-bottom:10px" onclick="genHash()">🔒 حساب</button>
        <div class="hash-result" id="hash-result" style="display:none"></div>
        <div class="status-msg" id="hash-msg"></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">🎲 <span data-i18n="pw_gen">مولّد كلمات المرور</span></div>
      <div class="input-row" style="flex-wrap:wrap;align-items:center">
        <label style="color:var(--muted);font-size:.82em;display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" id="pw-upper" checked> A-Z</label>
        <label style="color:var(--muted);font-size:.82em;display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" id="pw-lower" checked> a-z</label>
        <label style="color:var(--muted);font-size:.82em;display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" id="pw-nums" checked> 0-9</label>
        <label style="color:var(--muted);font-size:.82em;display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" id="pw-syms"> !@#$</label>
        <input class="inp" type="number" id="pw-len" value="16" min="4" max="64" style="max-width:75px">
        <button class="btn btn-primary" onclick="genPassword()">🎲 توليد</button>
      </div>
      <div id="pw-result" style="display:none;margin-top:9px">
        <div style="background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;padding:11px;display:flex;align-items:center;justify-content:space-between;gap:9px">
          <code id="pw-val" style="font-size:1.05em;color:#a78bfa;letter-spacing:2px;word-break:break-all"></code>
          <button class="btn btn-ghost btn-sm" onclick="copyText(document.getElementById('pw-val').textContent)">📋</button>
        </div>
        <div id="pw-strength" style="margin-top:7px;font-size:.82em"></div>
      </div>
    </div>
  </div>

  <!-- IMAGE TOOLS -->
  <div class="section" id="sec-image-tools">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🖼 <span data-i18n="img_tools">أدوات الصور</span></div>
        <div id="img-drop" onclick="document.getElementById('img-file').click()"
          style="border:2px dashed var(--border);border-radius:12px;padding:22px;text-align:center;cursor:pointer;margin-bottom:12px">
          <div style="font-size:32px;margin-bottom:7px">🖼</div>
          <div style="color:var(--muted);font-size:.87em" data-i18n="img_upload">اضغط لرفع صورة أو اسحبها</div>
        </div>
        <input type="file" id="img-file" accept="image/*" style="display:none" onchange="previewImg(this)">
        <div id="img-preview-wrap" style="display:none;text-align:center;margin-bottom:12px">
          <img id="img-preview" class="img-preview" src="" alt="">
          <div id="img-info" style="font-size:.75em;color:var(--muted);margin-top:5px"></div>
        </div>
        <div class="img-ops" id="img-ops" style="display:none">
          <button class="btn btn-ghost btn-sm" onclick="applyOp('grayscale')">⚫ رمادي</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('blur')">💧 ضبابي</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('sharpen')">✨ حدة</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('flip_h')">↔ قلب أفقي</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('flip_v')">↕ قلب رأسي</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('invert')">🔃 عكس</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('brightness')">☀ إضاءة</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('contrast')">🌓 تباين</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('rotate')">🔄 تدوير</button>
          <button class="btn btn-ghost btn-sm" onclick="applyOp('thumbnail')">🔍 مصغّرة</button>
        </div>
        <div class="status-msg" id="img-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">🖼 <span data-i18n="img_result">نتيجة المعالجة</span></div>
        <div id="img-result-wrap"><div class="empty"><div class="ei">🖼</div><p data-i18n="img_empty">ارفع صورة لبدء المعالجة</p></div></div>
      </div>
    </div>
  </div>

  <!-- NETWORK -->
  <div class="section" id="sec-network">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🌍 IP Lookup</div>
        <div class="input-row">
          <input class="inp" dir="ltr" id="ip-input" placeholder="8.8.8.8 أو example.com">
          <button class="btn btn-primary" onclick="lookupIP()" data-i18n="btn_check">فحص</button>
        </div>
        <div id="ip-result" style="display:none">
          <div class="result-grid" id="ip-grid"></div>
          <div id="ip-maps-section" style="display:none" class="coords-box">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
              <div>
                <div style="font-size:.78em;color:var(--muted);margin-bottom:3px">📍 الإحداثيات</div>
                <div id="ip-coords" style="font-size:.9em;color:#fff;direction:ltr;font-family:monospace"></div>
              </div>
              <a id="ip-maps-link" href="#" target="_blank" rel="noopener" class="maps-link">
                🗺 <span data-i18n="open_maps">فتح في جوجل ماب</span>
              </a>
            </div>
          </div>
        </div>
        <div class="status-msg" id="ip-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">📡 Ping</div>
        <div class="input-row">
          <input class="inp" dir="ltr" id="ping-input" placeholder="google.com أو 8.8.8.8">
          <button class="btn btn-info" onclick="doPing()" id="ping-btn">📡 Ping</button>
        </div>
        <div id="ping-result" style="display:none">
          <div id="ping-packets" style="display:flex;flex-direction:column;gap:5px;margin-bottom:9px"></div>
          <div id="ping-summary" style="background:rgba(255,255,255,.03);border-radius:8px;padding:9px;border:1px solid var(--border);font-size:.82em"></div>
        </div>
        <div class="status-msg" id="ping-msg"></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">🔎 <span data-i18n="url_check">فحص الرابط السريع</span></div>
      <div class="input-row">
        <input class="inp" dir="ltr" id="head-url" placeholder="https://example.com/file.zip">
        <button class="btn btn-warning" onclick="doHead()" data-i18n="btn_check">فحص</button>
      </div>
      <div id="head-result" style="display:none"><div class="result-grid" id="head-grid"></div></div>
      <div class="status-msg" id="head-msg"></div>
    </div>
  </div>

  <!-- NOTES -->
  <div class="section" id="sec-notes">
    <div class="card" style="margin-bottom:14px">
      <div class="card-title">📝 <span data-i18n="add_note">إضافة ملاحظة</span></div>
      <div class="input-row">
        <input class="inp" id="note-title" placeholder="العنوان (اختياري)">
        <input type="color" id="note-color" value="#7c3aed" style="height:42px;width:46px;flex-shrink:0;border-radius:10px;border:1px solid var(--border);background:none;cursor:pointer">
        <button class="btn btn-primary" onclick="addNote()">➕ <span data-i18n="btn_add">إضافة</span></button>
      </div>
      <textarea class="inp" id="note-content" rows="3" placeholder="المحتوى، رابط، نص..." style="width:100%;margin-top:0"></textarea>
      <div class="status-msg" id="note-msg"></div>
    </div>
    <div class="notes-grid" id="notes-grid">
      <div class="empty" style="grid-column:1/-1"><div class="ei">📝</div><p data-i18n="no_notes">لا توجد ملاحظات</p></div>
    </div>
  </div>

  <!-- PLATFORMS -->
  <div class="section" id="sec-platforms">
    <div class="card">
      <div class="card-title">📡 <span data-i18n="platforms_title">المنصات المدعومة</span> <span class="card-subtitle">19+</span></div>
      <div class="platforms-grid" id="all-platforms"></div>
    </div>
  </div>

  <!-- STATS -->
  <div class="section" id="sec-stats">
    <div class="stats-grid">
      <div class="stat-card" style="border-top:3px solid var(--accent)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(124,58,237,.15)">📥</div></div>
        <div class="stat-value" id="s-total">0</div><div class="stat-label" data-i18n="stat_total">إجمالي التحميلات</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--blue)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(59,130,246,.15)">🔍</div></div>
        <div class="stat-value" id="s-analyses">0</div><div class="stat-label" data-i18n="stat_analyses">التحليلات</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--green)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(16,185,129,.15)">✅</div></div>
        <div class="stat-value" id="s-rate">0%</div><div class="stat-label" data-i18n="stat_rate">معدل النجاح</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--yellow)">
        <div class="stat-top"><div class="stat-icon" style="background:rgba(245,158,11,.15)">⏱</div></div>
        <div class="stat-value" id="s-uptime">0:00</div><div class="stat-label" data-i18n="stat_uptime">وقت التشغيل</div>
      </div>
    </div>
    <div class="two-col">
      <div class="card">
        <div class="card-title">📊 <span data-i18n="stat_details">التفاصيل</span></div>
        <div class="result-grid" id="stats-details"></div>
      </div>
      <div class="card">
        <div class="card-title" style="justify-content:space-between">
          <span data-i18n="dl_history">سجل التحميلات</span>
          <button class="btn btn-danger btn-sm" onclick="clearHistory()">🗑 <span data-i18n="btn_clear">مسح</span></button>
        </div>
        <div class="history-list" id="hist-stats"><div class="empty"><div class="ei">📂</div><p data-i18n="no_history">لا يوجد سجل</p></div></div>
      </div>
    </div>
  </div>

  <!-- WEATHER -->
  <div class="section" id="sec-weather">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🌦 الطقس الحالي</div>
        <div class="input-row">
          <input class="inp" id="city-input" placeholder="اسم المدينة (مثال: Riyadh, Cairo)" dir="ltr">
          <button class="btn btn-info" onclick="fetchWeather()" id="weather-btn">🔍 بحث</button>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('Riyadh')">🇸🇦 الرياض</button>
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('Dubai')">🇦🇪 دبي</button>
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('Cairo')">🇪🇬 القاهرة</button>
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('London')">🇬🇧 لندن</button>
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('New York')">🇺🇸 نيويورك</button>
          <button class="btn btn-ghost btn-sm" onclick="setCityAndFetch('Tokyo')">🇯🇵 طوكيو</button>
        </div>
        <div id="weather-result" style="display:none">
          <div style="background:linear-gradient(135deg,rgba(124,58,237,.15),rgba(59,130,246,.1));border:1px solid rgba(124,58,237,.2);border-radius:14px;padding:20px;margin-bottom:14px">
            <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
              <div id="w-emoji" style="font-size:64px;line-height:1">☀️</div>
              <div>
                <div id="w-city" style="font-size:1.1em;color:#a78bfa;font-weight:700"></div>
                <div id="w-temp" style="font-size:2.8em;color:#fff;font-weight:800;line-height:1"></div>
                <div id="w-desc" style="color:var(--muted);font-size:.87em"></div>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px" id="w-details"></div>
          </div>
          <div id="w-forecast" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px"></div>
        </div>
        <div class="status-msg" id="weather-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">🕐 الساعة العالمية</div>
        <div id="world-clock" style="display:flex;flex-direction:column;gap:10px"></div>
        <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border)">
          <div class="card-title" style="margin-bottom:10px">📅 التاريخ والوقت</div>
          <div id="timestamp-info" style="display:grid;grid-template-columns:1fr 1fr;gap:8px"></div>
          <button class="btn btn-ghost btn-sm" style="margin-top:10px" onclick="loadTimestamp()">🔄 تحديث</button>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">💬 اقتباس اليوم</div>
      <div id="quote-box" style="text-align:center;padding:24px">
        <div id="quote-text" style="font-size:1.2em;color:#fff;font-style:italic;margin-bottom:10px;line-height:1.8">جاري التحميل...</div>
        <div id="quote-author" style="color:var(--muted);font-size:.87em">—</div>
        <button class="btn btn-ghost btn-sm" style="margin-top:14px" onclick="loadQuote()">🔄 اقتباس جديد</button>
      </div>
    </div>
  </div>

  <!-- CURRENCY -->
  <div class="section" id="sec-currency">
    <div class="two-col">
      <div class="card">
        <div class="card-title">💱 محوّل العملات الفوري</div>
        <div class="input-row">
          <input class="inp" type="number" id="cur-amount" value="1" min="0" step="any" style="max-width:100px">
          <select class="inp" id="cur-from" style="max-width:120px"></select>
          <div style="display:flex;align-items:center;font-size:1.4em;color:var(--accent);flex-shrink:0">⇄</div>
          <select class="inp" id="cur-to" style="max-width:120px"></select>
          <button class="btn btn-primary" onclick="convertCurrency()">💱 تحويل</button>
        </div>
        <div id="cur-result" style="display:none;margin-top:12px">
          <div style="background:linear-gradient(135deg,rgba(16,185,129,.1),rgba(59,130,246,.08));border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:20px;text-align:center">
            <div style="font-size:.87em;color:var(--muted);margin-bottom:6px">النتيجة</div>
            <div id="cur-output" style="font-size:2.4em;font-weight:800;color:#34d399"></div>
            <div id="cur-rate-info" style="font-size:.8em;color:var(--muted);margin-top:6px"></div>
          </div>
        </div>
        <div class="status-msg" id="cur-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">📊 أسعار الصرف الرئيسية <span class="card-subtitle" id="rates-base-lbl">USD</span></div>
        <div class="input-row" style="margin-bottom:10px">
          <select class="inp" id="rates-base" style="max-width:100px"></select>
          <button class="btn btn-info btn-sm" onclick="loadRates()">🔄</button>
        </div>
        <div id="rates-grid" style="display:grid;grid-template-columns:repeat(2,1fr);gap:7px"></div>
        <div class="status-msg" id="rates-msg"></div>
      </div>
    </div>
  </div>

  <!-- BATCH DOWNLOADER -->
  <div class="section" id="sec-batch">
    <div class="card">
      <div class="card-title">⬇ تحميل متعدد دفعي</div>
      <p style="color:var(--muted);font-size:.87em;margin-bottom:12px">الصق روابط متعددة (رابط في كل سطر) — حتى 10 روابط دفعة واحدة</p>
      <textarea class="inp" id="batch-urls" rows="6" placeholder="https://youtube.com/watch?v=...&#10;https://example.com/file.zip&#10;https://tiktok.com/..." style="width:100%;direction:ltr;font-family:monospace;font-size:.82em"></textarea>
      <div class="input-row" style="margin-top:10px">
        <select class="inp" id="batch-quality" style="max-width:120px">
          <option value="720p">720p</option><option value="1080p">1080p</option>
          <option value="480p">480p</option><option value="صوت فقط (MP3)">MP3</option>
        </select>
        <button class="btn btn-info" onclick="analyzeBatch()">🔍 تحليل الروابط</button>
        <button class="btn btn-primary" id="batch-dl-btn" style="display:none" onclick="startBatch()">⬇ تحميل الكل</button>
      </div>
    </div>
    <div id="batch-results" style="display:none">
      <div id="batch-list" style="display:flex;flex-direction:column;gap:10px"></div>
    </div>
    <div class="status-msg" id="batch-msg" style="margin-top:10px"></div>
  </div>

  <!-- URL SHORTENER -->
  <div class="section" id="sec-shortener">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🔗 مختصر الروابط</div>
        <p style="color:var(--muted);font-size:.87em;margin-bottom:12px">اختصر أي رابط طويل إلى رابط قصير وسهل المشاركة</p>
        <div class="input-row">
          <input class="inp" dir="ltr" id="shorten-url" placeholder="https://example.com/very/long/url?with=params">
          <button class="btn btn-ghost btn-sm" onclick="pasteClipboard('shorten-url')">📋</button>
          <button class="btn btn-primary" onclick="shortenURL()">✂ اختصار</button>
        </div>
        <div id="shorten-result" style="display:none;margin-top:12px">
          <div style="background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:16px">
            <div style="font-size:.78em;color:var(--muted);margin-bottom:6px">الرابط المختصر</div>
            <div style="display:flex;align-items:center;gap:10px">
              <a id="short-link" href="#" target="_blank" style="color:#34d399;font-size:1.05em;direction:ltr;font-weight:600;word-break:break-all"></a>
              <button class="btn btn-ghost btn-sm" onclick="copyText(document.getElementById('short-link').textContent)">📋</button>
            </div>
            <div id="short-service" style="font-size:.75em;color:var(--muted);margin-top:5px"></div>
            <div id="short-qr" style="margin-top:12px;display:none;text-align:center">
              <img id="short-qr-img" src="" style="max-width:140px;border-radius:8px;background:#fff;padding:6px">
            </div>
            <button class="btn btn-info btn-sm" style="margin-top:10px" onclick="genShortQR()">🔲 إنشاء QR للرابط المختصر</button>
          </div>
        </div>
        <div class="status-msg" id="shorten-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">📋 روابط مختصرة سابقة</div>
        <div id="short-history" style="display:flex;flex-direction:column;gap:8px;max-height:300px;overflow-y:auto">
          <div class="empty"><div class="ei">🔗</div><p>لا يوجد سجل</p></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ADVANCED TOOLS -->
  <div class="section" id="sec-adv-tools">
    <div class="two-col" style="margin-bottom:14px">
      <!-- Calculator -->
      <div class="card">
        <div class="card-title">🧮 آلة حاسبة علمية</div>
        <div style="background:rgba(0,0,0,.3);border-radius:12px;padding:14px;margin-bottom:12px">
          <div id="calc-expr" style="font-size:.82em;color:var(--muted);min-height:18px;direction:ltr;text-align:left;margin-bottom:4px;word-break:break-all"></div>
          <div id="calc-display" style="font-size:2.2em;color:#fff;font-weight:700;direction:ltr;text-align:left;min-height:44px;word-break:break-all;font-family:monospace">0</div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px">
          <button class="btn btn-danger btn-sm" onclick="calcClear()" style="grid-column:span 2">AC</button>
          <button class="btn btn-warning btn-sm" onclick="calcDel()">⌫</button>
          <button class="btn btn-warning btn-sm" onclick="calcInput('/')">÷</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('7')">7</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('8')">8</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('9')">9</button>
          <button class="btn btn-warning btn-sm" onclick="calcInput('*')">×</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('4')">4</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('5')">5</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('6')">6</button>
          <button class="btn btn-warning btn-sm" onclick="calcInput('-')">−</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('1')">1</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('2')">2</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('3')">3</button>
          <button class="btn btn-warning btn-sm" onclick="calcInput('+')">+</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('0')" style="grid-column:span 2">0</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('.')">.</button>
          <button class="btn btn-primary btn-sm" onclick="calcEval()">=</button>
          <button class="btn btn-ghost btn-sm" onclick="calcSci('Math.sqrt(',')')">√</button>
          <button class="btn btn-ghost btn-sm" onclick="calcSci('Math.pow(',',2)')">x²</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('(')">(</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput(')')">)</button>
          <button class="btn btn-ghost btn-sm" onclick="calcSci('Math.sin(Math.PI/180*',')')">sin</button>
          <button class="btn btn-ghost btn-sm" onclick="calcSci('Math.cos(Math.PI/180*',')')">cos</button>
          <button class="btn btn-ghost btn-sm" onclick="calcSci('Math.tan(Math.PI/180*',')')">tan</button>
          <button class="btn btn-ghost btn-sm" onclick="calcInput('Math.PI')">π</button>
        </div>
        <div id="calc-history" style="margin-top:10px;max-height:80px;overflow-y:auto;font-size:.78em;color:var(--muted);direction:ltr"></div>
      </div>

      <!-- Unit Converter -->
      <div class="card">
        <div class="card-title">📐 محوّل الوحدات</div>
        <div style="margin-bottom:10px">
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px" id="unit-cats">
            <button class="btn btn-primary btn-sm" onclick="setUnitCat('length')">📏 طول</button>
            <button class="btn btn-ghost btn-sm" onclick="setUnitCat('weight')">⚖ وزن</button>
            <button class="btn btn-ghost btn-sm" onclick="setUnitCat('temp')">🌡 حرارة</button>
            <button class="btn btn-ghost btn-sm" onclick="setUnitCat('area')">📐 مساحة</button>
            <button class="btn btn-ghost btn-sm" onclick="setUnitCat('speed')">🚀 سرعة</button>
            <button class="btn btn-ghost btn-sm" onclick="setUnitCat('data')">💾 بيانات</button>
          </div>
          <div class="input-row">
            <input class="inp" type="number" id="unit-val" value="1" oninput="convertUnit()">
            <select class="inp" id="unit-from" onchange="convertUnit()"></select>
            <span style="color:var(--accent);font-size:1.2em;flex-shrink:0">→</span>
            <select class="inp" id="unit-to" onchange="convertUnit()"></select>
          </div>
          <div id="unit-result" style="background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;padding:14px;text-align:center">
            <span id="unit-output" style="font-size:1.6em;color:#a78bfa;font-weight:700">—</span>
          </div>
        </div>
      </div>
    </div>

    <div class="two-col">
      <!-- JSON Formatter -->
      <div class="card">
        <div class="card-title">🔧 JSON محرّر ومنسّق</div>
        <textarea class="inp" id="json-input" rows="6" placeholder='{"key": "value", "arr": [1,2,3]}' style="width:100%;direction:ltr;font-family:monospace;font-size:.82em;margin-bottom:10px"></textarea>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px">
          <button class="btn btn-primary btn-sm" onclick="formatJSON()">✨ تنسيق</button>
          <button class="btn btn-ghost btn-sm" onclick="minifyJSON()">🗜 ضغط</button>
          <button class="btn btn-info btn-sm" onclick="validateJSON()">✅ تحقق</button>
          <button class="btn btn-ghost btn-sm" onclick="copyText(document.getElementById('json-output').textContent)">📋 نسخ</button>
        </div>
        <div id="json-output" style="background:rgba(0,0,0,.3);border-radius:10px;padding:12px;font-size:.8em;font-family:monospace;direction:ltr;white-space:pre;overflow-x:auto;max-height:200px;overflow-y:auto;color:#a78bfa;min-height:60px"></div>
        <div class="status-msg" id="json-msg"></div>
      </div>

      <!-- Regex Tester -->
      <div class="card">
        <div class="card-title">🎯 مختبر Regex</div>
        <div class="input-row">
          <input class="inp" dir="ltr" id="regex-pattern" placeholder="pattern (e.g. \d+)" style="font-family:monospace" oninput="testRegex()">
          <select class="inp" style="max-width:80px" id="regex-flags" onchange="testRegex()">
            <option value="g">g</option><option value="gi">gi</option>
            <option value="gm">gm</option><option value="gim">gim</option>
          </select>
        </div>
        <textarea class="inp" id="regex-text" rows="4" placeholder="النص للاختبار..." style="width:100%;direction:ltr;font-family:monospace;font-size:.82em;margin-bottom:10px" oninput="testRegex()"></textarea>
        <div id="regex-result" style="display:none">
          <div id="regex-highlighted" style="background:rgba(0,0,0,.3);border-radius:10px;padding:12px;font-size:.82em;font-family:monospace;direction:ltr;min-height:50px;line-height:1.8;word-break:break-all"></div>
          <div id="regex-matches" style="margin-top:8px;font-size:.8em;color:var(--muted)"></div>
        </div>
        <div class="status-msg" id="regex-msg"></div>
      </div>
    </div>

    <!-- Markdown Editor -->
    <div class="card">
      <div class="card-title">📝 محرّر Markdown مع معاينة حية</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div>
          <div style="font-size:.78em;color:var(--muted);margin-bottom:7px">✏️ الكتابة</div>
          <textarea class="inp" id="md-input" rows="12" style="width:100%;direction:ltr;font-family:monospace;font-size:.82em;resize:vertical" oninput="renderMarkdown()" placeholder="# عنوان&#10;## عنوان فرعي&#10;**نص غامق** و *مائل*&#10;- عنصر قائمة&#10;`كود`&#10;[رابط](https://example.com)"></textarea>
        </div>
        <div>
          <div style="font-size:.78em;color:var(--muted);margin-bottom:7px">👁 المعاينة</div>
          <div id="md-preview" style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:10px;padding:14px;min-height:200px;overflow-y:auto;direction:ltr;font-size:.87em;line-height:1.8;color:var(--text)"></div>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('**','**')"><b>B</b></button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('*','*')"><i>I</i></button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('`','`')">Code</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('\n# ','')">H1</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('\n## ','')">H2</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('\n- ','')">List</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('\n> ','')">Quote</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('[','](url)')">Link</button>
        <button class="btn btn-ghost btn-sm" onclick="mdInsert('\n---\n','')">HR</button>
        <button class="btn btn-danger btn-sm" onclick="document.getElementById('md-input').value='';renderMarkdown()">🗑</button>
        <button class="btn btn-success btn-sm" onclick="copyText(document.getElementById('md-input').value)">📋 نسخ MD</button>
      </div>
    </div>
  </div>

  <!-- SETTINGS -->
  <div class="section" id="sec-settings">
    <div class="two-col">
      <div class="card">
        <div class="card-title">🔒 <span data-i18n="change_code">تغيير رمز الدخول</span></div>
        <div style="display:flex;flex-direction:column;gap:9px">
          <input class="inp" type="password" id="cur-code" placeholder="الرمز الحالي">
          <input class="inp" type="password" id="new-code" placeholder="الرمز الجديد">
          <input class="inp" type="password" id="new-code2" placeholder="تأكيد الرمز">
          <button class="btn btn-primary" onclick="changeCode()">💾 <span data-i18n="btn_save">حفظ</span></button>
        </div>
        <div class="status-msg" id="code-msg"></div>
      </div>
      <div class="card">
        <div class="card-title">🎨 <span data-i18n="customization">التخصيص</span></div>
        <div style="display:flex;flex-direction:column;gap:11px">
          <div class="setting-item">
            <div><div class="setting-label" data-i18n="accent_color">لون الواجهة</div></div>
            <input type="color" id="accent-color" value="#7c3aed" onchange="previewAccent(this.value)">
          </div>
          <div class="setting-item">
            <div><div class="setting-label" data-i18n="font_size">حجم الخط</div><div class="setting-desc" id="fs-label">14px</div></div>
            <div class="range-wrap" style="max-width:130px">
              <input type="range" id="font-slider" min="11" max="20" value="14" step="1" oninput="changeFontSize(this.value)">
            </div>
          </div>
          <div class="setting-item">
            <div><div class="setting-label" data-i18n="language">اللغة</div></div>
            <div style="display:flex;gap:6px">
              <button class="btn btn-ghost btn-sm" id="lang-ar-btn" onclick="setLang('ar')" style="font-weight:700;border-color:var(--accent)">العربية</button>
              <button class="btn btn-ghost btn-sm" id="lang-en-btn" onclick="setLang('en')">English</button>
            </div>
          </div>
          <div class="setting-item">
            <div><div class="setting-label" data-i18n="default_quality">الجودة الافتراضية</div></div>
            <select class="inp" id="def-quality" style="max-width:110px">
              <option value="4K">4K</option><option value="1080p">1080p</option>
              <option value="720p" selected>720p</option><option value="480p">480p</option><option value="360p">360p</option>
            </select>
          </div>
          <button class="btn btn-primary" onclick="saveAppSettings()">💾 <span data-i18n="btn_save">حفظ التخصيص</span></button>
        </div>
        <div class="status-msg" id="theme-msg"></div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">⚙️ <span data-i18n="advanced_settings">الإعدادات المتقدمة</span></div>
      <div class="settings-grid">
        <div class="setting-item">
          <div><div class="setting-label" data-i18n="set_notify">إشعار عند الاكتمال</div><div class="setting-desc" data-i18n="set_notify_desc">إشعار المتصفح</div></div>
          <label class="toggle"><input type="checkbox" id="set-notify" checked><span class="toggle-slider"></span></label>
        </div>
        <div class="setting-item">
          <div><div class="setting-label" data-i18n="set_auto">اكتشاف تلقائي للرابط</div></div>
          <label class="toggle"><input type="checkbox" id="set-autodetect" checked><span class="toggle-slider"></span></label>
        </div>
        <div class="setting-item">
          <div><div class="setting-label" data-i18n="set_history">حفظ سجل التحميلات</div></div>
          <label class="toggle"><input type="checkbox" id="set-history" checked><span class="toggle-slider"></span></label>
        </div>
        <div class="setting-item">
          <div><div class="setting-label" data-i18n="set_thumbs">عرض الصور المصغرة</div></div>
          <label class="toggle"><input type="checkbox" id="set-thumbs" checked><span class="toggle-slider"></span></label>
        </div>
      </div>
      <div style="display:flex;gap:9px;margin-top:12px;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="saveAdvancedSettings()">💾 <span data-i18n="btn_save">حفظ</span></button>
        <button class="btn btn-danger" onclick="resetSettings()">🔄 <span data-i18n="btn_reset">إعادة ضبط</span></button>
        <button class="btn btn-ghost" onclick="clearHistory()">🗑 <span data-i18n="btn_clear_hist">مسح السجل</span></button>
        <button id="pwa-install-btn2" class="btn btn-success" style="display:none" onclick="installPWA()">📲 <span data-i18n="install_app">تثبيت التطبيق</span></button>
      </div>
      <div class="status-msg" id="adv-msg"></div>
    </div>

    <div class="card">
      <div class="card-title">ℹ️ <span data-i18n="app_info">معلومات التطبيق</span></div>
      <div class="result-grid" id="app-info-grid"></div>
    </div>
  </div>
</div><!-- end main -->

<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
<script>
// ======================== i18n ========================
const LANGS = {
  ar: {
    app_name:'مركز التحميل',nav_main:'الرئيسي',nav_home:'الرئيسية',nav_active:'النشطة',
    nav_download:'التحميل',nav_video:'تحميل فيديو',nav_file:'تحميل ملف',nav_myfiles:'ملفاتي',
    nav_tools:'أدوات',nav_analyze:'تحليل رابط',nav_qr:'باركود QR',nav_text:'أدوات النصوص',
    nav_img:'أدوات الصور',nav_net:'أدوات الشبكة',nav_other:'أخرى',nav_notes:'ملاحظات',
    nav_platforms:'المنصات',nav_stats:'الإحصائيات',nav_settings:'الإعدادات',nav_logout:'خروج',
    stat_total:'إجمالي التحميلات',stat_videos:'فيديوهات',stat_files:'ملفات',stat_size:'الحجم المحمّل',
    stat_analyses:'التحليلات',stat_rate:'معدل النجاح',stat_uptime:'وقت التشغيل',stat_details:'التفاصيل',
    quick_start:'بدء سريع',disk_space:'مساحة القرص',recent_dl:'آخر التحميلات',no_downloads:'لا توجد تحميلات بعد',
    active_dl:'التحميلات النشطة',all_history:'سجل التحميلات',no_active:'لا توجد تحميلات جارية',no_history:'لا يوجد سجل',
    video_title:'تحميل فيديو من أي منصة',file_title:'تحميل ملف برابط مباشر',my_files:'ملفاتي',no_files:'لا توجد ملفات',
    analyze_title:'تحليل رابط شامل',qr_gen:'إنشاء باركود QR',qr_read:'قراءة باركود QR',
    qr_color:'لون الباركود',qr_bg:'لون الخلفية',qr_size:'الحجم',qr_create:'إنشاء الباركود',qr_drop:'اضغط لاختيار صورة أو اسحبها',
    encode_title:'تشفير / فك تشفير',hash_title:'مولّد الهاش',pw_gen:'مولّد كلمات المرور',
    img_tools:'أدوات الصور',img_result:'نتيجة المعالجة',img_upload:'اضغط لرفع صورة أو اسحبها',img_empty:'ارفع صورة لبدء المعالجة',
    url_check:'فحص الرابط السريع',add_note:'إضافة ملاحظة',no_notes:'لا توجد ملاحظات',
    platforms_title:'المنصات المدعومة',dl_history:'سجل التحميلات',
    change_code:'تغيير رمز الدخول',customization:'التخصيص',accent_color:'لون الواجهة',
    font_size:'حجم الخط',language:'اللغة',default_quality:'الجودة الافتراضية',
    advanced_settings:'الإعدادات المتقدمة',set_notify:'إشعار عند الاكتمال',set_notify_desc:'إشعار المتصفح',
    set_auto:'اكتشاف تلقائي',set_history:'حفظ السجل',set_thumbs:'الصور المصغرة',app_info:'معلومات التطبيق',
    install_app:'تثبيت التطبيق',status_running:'مشغّل',open_maps:'فتح في جوجل ماب',
    supported_platforms:'منصات الفيديو المدعومة',
    btn_analyze:'تحليل',btn_fetch:'جلب المعلومات',btn_download:'تحميل',btn_check:'فحص',
    btn_save:'حفظ',btn_add:'إضافة',btn_clear:'مسح',btn_reset:'إعادة ضبط',btn_clear_hist:'مسح السجل',
    nav_weather:'🌦 الطقس والعالم',nav_currency:'💱 محوّل العملات',nav_batch:'⬇ تحميل متعدد',
    nav_shortener:'🔗 مختصر الروابط',nav_advtools:'🧰 أدوات متقدمة',
  },
  en: {
    app_name:'Smart Downloader',nav_main:'Main',nav_home:'Home',nav_active:'Active',
    nav_download:'Downloads',nav_video:'Download Video',nav_file:'Download File',nav_myfiles:'My Files',
    nav_tools:'Tools',nav_analyze:'Analyze URL',nav_qr:'QR Code',nav_text:'Text Tools',
    nav_img:'Image Tools',nav_net:'Network Tools',nav_other:'Other',nav_notes:'Notes',
    nav_platforms:'Platforms',nav_stats:'Statistics',nav_settings:'Settings',nav_logout:'Logout',
    stat_total:'Total Downloads',stat_videos:'Videos',stat_files:'Files',stat_size:'Downloaded Size',
    stat_analyses:'Analyses',stat_rate:'Success Rate',stat_uptime:'Uptime',stat_details:'Details',
    quick_start:'Quick Start',disk_space:'Disk Space',recent_dl:'Recent Downloads',no_downloads:'No downloads yet',
    active_dl:'Active Downloads',all_history:'Download History',no_active:'No active downloads',no_history:'No history',
    video_title:'Download Video from Any Platform',file_title:'Download File by Direct URL',my_files:'My Files',no_files:'No files found',
    analyze_title:'Full URL Analysis',qr_gen:'Generate QR Code',qr_read:'Read QR Code',
    qr_color:'QR Color',qr_bg:'Background',qr_size:'Size',qr_create:'Generate',qr_drop:'Click or drag image here',
    encode_title:'Encode / Decode',hash_title:'Hash Generator',pw_gen:'Password Generator',
    img_tools:'Image Tools',img_result:'Result',img_upload:'Click or drag image here',img_empty:'Upload an image to start',
    url_check:'Quick URL Check',add_note:'Add Note',no_notes:'No notes yet',
    platforms_title:'Supported Platforms',dl_history:'Download History',
    change_code:'Change Access Code',customization:'Customization',accent_color:'Accent Color',
    font_size:'Font Size',language:'Language',default_quality:'Default Quality',
    advanced_settings:'Advanced Settings',set_notify:'Notify on Complete',set_notify_desc:'Browser notification',
    set_auto:'Auto-detect URL type',set_history:'Save History',set_thumbs:'Show Thumbnails',app_info:'App Info',
    install_app:'Install App',status_running:'Running',open_maps:'Open in Google Maps',
    supported_platforms:'Supported Platforms',
    btn_analyze:'Analyze',btn_fetch:'Get Info',btn_download:'Download',btn_check:'Check',
    btn_save:'Save',btn_add:'Add',btn_clear:'Clear',btn_reset:'Reset',btn_clear_hist:'Clear History',
    nav_weather:'🌦 Weather & World',nav_currency:'💱 Currency',nav_batch:'⬇ Batch Download',
    nav_shortener:'🔗 URL Shortener',nav_advtools:'🧰 Advanced Tools',
  }
};

let currentLang = localStorage.getItem('lang') || 'ar';
function applyLang(lang) {
  currentLang = lang;
  localStorage.setItem('lang', lang);
  document.getElementById('html-root').lang = lang;
  document.getElementById('html-root').dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.getElementById('lang-btn').textContent = lang === 'ar' ? 'EN' : 'ع';
  const t = LANGS[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (t[key] !== undefined) el.textContent = t[key];
  });
  // Update lang buttons
  const arb = document.getElementById('lang-ar-btn');
  const enb = document.getElementById('lang-en-btn');
  if (arb && enb) {
    arb.style.borderColor = lang==='ar' ? 'var(--accent)' : '';
    arb.style.color = lang==='ar' ? '#a78bfa' : '';
    enb.style.borderColor = lang==='en' ? 'var(--accent)' : '';
    enb.style.color = lang==='en' ? '#a78bfa' : '';
  }
}
function toggleLang() { setLang(currentLang === 'ar' ? 'en' : 'ar'); }
function setLang(l) { applyLang(l); }

// ======================== FONT SIZE ========================
function changeFontSize(val) {
  document.documentElement.style.setProperty('--fs', val + 'px');
  localStorage.setItem('fontSize', val);
  const lbl = document.getElementById('fs-label');
  if (lbl) lbl.textContent = val + 'px';
  const slider = document.getElementById('font-slider');
  if (slider) slider.value = val;
}
function initFontSize() {
  const saved = localStorage.getItem('fontSize') || '14';
  changeFontSize(saved);
}

// ======================== PWA ========================
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('install-btn').style.display = 'flex';
  const b2 = document.getElementById('pwa-install-btn2');
  if (b2) b2.style.display = 'inline-flex';
});
window.addEventListener('appinstalled', () => {
  deferredPrompt = null;
  document.getElementById('install-btn').style.display = 'none';
  const b2 = document.getElementById('pwa-install-btn2');
  if (b2) b2.style.display = 'none';
  showToast('✅ تم تثبيت التطبيق بنجاح!');
});
async function installPWA() {
  if (!deferredPrompt) { showToast('ℹ️ التطبيق مثبّت مسبقاً أو غير مدعوم'); return; }
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === 'accepted') showToast('✅ جاري التثبيت...');
  deferredPrompt = null;
}

// Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(()=>{});
}

// ======================== CLOCK ========================
function updateClock() {
  const now = new Date();
  const t = now.toLocaleTimeString(currentLang==='ar'?'ar-SA':'en-US');
  document.getElementById('clock').textContent = now.toLocaleDateString(currentLang==='ar'?'ar-SA':'en-US') + '  ' + t;
  document.getElementById('clock-small').textContent = t;
}
setInterval(updateClock, 1000); updateClock();

// ======================== NAV ========================
const TITLES = {
  home:'nav_home',downloads:'nav_active',video:'nav_video',file:'nav_file',
  'files-list':'nav_myfiles',analyze:'nav_analyze',qrcode:'nav_qr',
  'text-tools':'nav_text','image-tools':'nav_img',network:'nav_net',
  notes:'nav_notes',platforms:'nav_platforms',stats:'nav_stats',settings:'nav_settings',
  weather:'nav_weather',currency:'nav_currency',batch:'nav_batch',
  shortener:'nav_shortener','adv-tools':'nav_advtools',
};
function go(name, btn) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('sec-'+name).classList.add('active');
  if (btn) btn.classList.add('active');
  const titleKey = TITLES[name];
  document.getElementById('page-title').textContent = LANGS[currentLang][titleKey] || name;
  closeSidebar();
  if (['home','stats'].includes(name)) loadStats();
  if (name==='files-list') loadFiles();
  if (['platforms','video'].includes(name)) buildPlatforms();
  if (name==='notes') loadNotes();
  if (name==='home') loadDisk();
  if (name==='settings') loadSettings();
  if (name==='weather') { loadTimestamp(); }
  if (name==='currency') { loadRates(); }
  if (name==='shortener') renderShortHistory();
}
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); }

// ======================== ACCENT COLOR ========================
function previewAccent(color) {
  document.documentElement.style.setProperty('--accent', color);
  localStorage.setItem('accentColor', color);
}
function initAccent() {
  const c = localStorage.getItem('accentColor');
  if (c) { previewAccent(c); const el = document.getElementById('accent-color'); if (el) el.value = c; }
}

// ======================== CLIPBOARD ========================
async function pasteClipboard(id) {
  try { document.getElementById(id).value = await navigator.clipboard.readText(); }
  catch { showToast('⚠️ تعذّر الوصول للحافظة'); }
}
function copyText(text) {
  navigator.clipboard.writeText(text)
    .then(() => showToast('✅ ' + (currentLang==='ar'?'تم النسخ':'Copied!')))
    .catch(() => showToast('❌ فشل النسخ'));
}

// ======================== TOAST ========================
function showToast(msg, dur=2200) {
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.cssText = 'position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#1e1e30;color:#fff;border:1px solid rgba(255,255,255,0.1);padding:10px 20px;border-radius:10px;font-size:.87em;z-index:9999;animation:fadeIn .2s;box-shadow:0 4px 16px rgba(0,0,0,.4);white-space:nowrap';
  document.body.appendChild(t);
  setTimeout(() => t.remove(), dur);
}

// ======================== STATS ========================
let progressIntervals = {};
async function loadStats() {
  try {
    const d = await (await fetch('/api/stats')).json();
    setTxt('h-total', d.total_downloads);
    setTxt('h-videos', d.video_downloads);
    setTxt('h-files', d.file_downloads);
    setTxt('h-size', d.size_downloaded);
    setTxt('s-total', d.total_downloads);
    setTxt('s-analyses', d.total_analyses);
    setTxt('s-rate', d.success_rate+'%');
    setTxt('s-uptime', d.uptime||'0:00');
    const dets = document.getElementById('stats-details');
    if (dets) dets.innerHTML = [
      {l:'🎬 '+LANGS[currentLang].stat_videos,v:d.video_downloads},
      {l:'📁 '+LANGS[currentLang].stat_files,v:d.file_downloads},
      {l:'❌ '+( currentLang==='ar'?'أخطاء':'Errors'),v:d.errors},
      {l:'🔍 '+LANGS[currentLang].stat_analyses,v:d.total_analyses},
      {l:'💾 '+LANGS[currentLang].stat_size,v:d.size_downloaded},
      {l:'🔢 '+(currentLang==='ar'?'جلسات':'Sessions'),v:d.sessions},
    ].map(x=>`<div class="result-item"><label>${x.l}</label><span>${x.v}</span></div>`).join('');
    renderHistory(d.history, 'hist-home');
    renderHistory(d.history, 'hist-all');
    renderHistory(d.history, 'hist-stats');
    loadActiveDownloads();
  } catch(e){}
}
setInterval(loadStats, 8000); loadStats();

function setTxt(id, val) { const e = document.getElementById(id); if (e) e.textContent = val; }
function renderHistory(hist, cid) {
  const c = document.getElementById(cid); if (!c) return;
  if (!hist?.length) { c.innerHTML=`<div class="empty"><div class="ei">📂</div><p>${LANGS[currentLang].no_history}</p></div>`; return; }
  c.innerHTML = hist.map(h=>`
    <div class="hist-item">
      <div class="hist-icon">${h.type==='فيديو'?'🎬':'📁'}</div>
      <div class="hist-info">
        <div class="hist-name">${h.name}</div>
        <div class="hist-meta">${h.platform} · ${h.size} · ${h.time}</div>
      </div>
      <div class="hist-badge">${h.quality}</div>
    </div>`).join('');
}

// ======================== DISK ========================
async function loadDisk() {
  try {
    const d = await (await fetch('/api/disk-space')).json();
    const pct = 100 - d.free_pct;
    const color = pct > 85 ? '#ef4444' : pct > 65 ? '#f59e0b' : 'var(--accent)';
    document.getElementById('disk-info').innerHTML = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:9px">
        <div style="font-size:.82em;color:var(--muted)">${currentLang==='ar'?'المجموع':'Total'}: <span style="color:#fff">${d.total}</span></div>
        <div style="font-size:.82em;color:var(--muted)">${currentLang==='ar'?'المستخدم':'Used'}: <span style="color:#fff">${d.used}</span></div>
        <div style="font-size:.82em;color:var(--muted)">${currentLang==='ar'?'المتاح':'Free'}: <span style="color:#34d399">${d.free}</span></div>
        <div style="font-size:.82em;color:var(--muted)">${currentLang==='ar'?'تحميلاتي':'My Downloads'}: <span style="color:#a78bfa">${d.app_size}</span></div>
      </div>
      <div class="disk-bar"><div class="disk-fill" style="width:${pct}%;background:linear-gradient(90deg,${color},${color}aa)"></div></div>
      <div style="font-size:.72em;color:var(--muted);margin-top:4px;direction:ltr;text-align:left">${pct.toFixed(1)}% used</div>`;
  } catch { document.getElementById('disk-info').innerHTML = '<span style="color:var(--muted);font-size:.82em">Error loading disk info</span>'; }
}

// ======================== ACTIVE DOWNLOADS ========================
async function loadActiveDownloads() {
  try {
    const d = await (await fetch('/api/active-downloads')).json();
    const cnt = d.downloads.length;
    const badge = document.getElementById('dl-badge');
    setTxt('dl-count', cnt); badge.style.display = cnt>0?'flex':'none';
    setTxt('active-count', cnt);
    const cont = document.getElementById('active-list'); if (!cont) return;
    if (!cnt) { cont.innerHTML=`<div class="empty"><div class="ei">✅</div><p>${LANGS[currentLang].no_active}</p></div>`; return; }
    cont.innerHTML = d.downloads.map(dl=>`
      <div class="dl-item">
        <div class="dl-item-top">
          <div class="dl-name">${dl.url||dl.id}</div>
          <div class="dl-status">${dl.status||''} ${dl.speed?'· '+dl.speed:''} ${dl.eta?'· '+dl.eta:''}</div>
        </div>
        <div class="progress-bar" style="margin-top:5px"><div class="progress-fill" style="width:${dl.progress||0}%"></div></div>
      </div>`).join('');
  } catch {}
}
setInterval(loadActiveDownloads, 3000);

// ======================== QUICK ACTION ========================
async function quickAction() {
  const url = document.getElementById('quick-url').value.trim(); if (!url) return;
  const res = document.getElementById('quick-result');
  res.innerHTML = '<div class="status-msg status-info show">⏳ ...</div>';
  const d = await postJson('/api/video-info', {url});
  if (d.success) {
    res.innerHTML = `<div class="status-msg status-success show">🎬 <b>${d.title}</b><br>${d.platform} · ${d.duration}
      <div style="margin-top:8px;display:flex;gap:7px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('vid-url').value='${esc(url)}';go('video',document.querySelectorAll('.nav-item')[3])">⬇ ${LANGS[currentLang].nav_video}</button>
      </div></div>`;
  } else {
    res.innerHTML = `<div class="status-msg status-info show">🔗 ${currentLang==='ar'?'رابط عادي':'Regular link'}
      <div style="margin-top:8px;display:flex;gap:7px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('file-url').value='${esc(url)}';go('file',document.querySelectorAll('.nav-item')[4])">⬇ ${LANGS[currentLang].nav_file}</button>
        <button class="btn btn-info btn-sm" onclick="document.getElementById('analyze-url').value='${esc(url)}';go('analyze',document.querySelectorAll('.nav-item')[7])">🔍 ${LANGS[currentLang].btn_analyze}</button>
      </div></div>`;
  }
}

// ======================== VIDEO ========================
async function fetchVideoInfo() {
  const url = document.getElementById('vid-url').value.trim();
  if (!url) return showMsg('vid-msg','❌ '+(currentLang==='ar'?'أدخل الرابط':'Enter URL'),'error');
  const btn = document.getElementById('vid-fetch-btn');
  btn.disabled=true; btn.innerHTML='<span class="loader"></span>';
  hideEl('vid-info'); clearMsg('vid-msg');
  const d = await postJson('/api/video-info', {url});
  if (d.success) {
    document.getElementById('vid-thumb').src = d.thumbnail||'';
    setTxt('vid-title', d.title);
    document.getElementById('vid-meta').innerHTML = [
      `<span class="meta-tag">🌐 ${d.platform}</span>`,
      `<span class="meta-tag">⏱ ${d.duration}</span>`,
      `<span class="meta-tag">👤 ${d.uploader}</span>`,
      d.view_count!=='غير معروف'?`<span class="meta-tag">👁 ${d.view_count}</span>`:'',
    ].join('');
    setTxt('vid-desc', d.description||'');
    const sel = document.getElementById('vid-quality');
    sel.innerHTML = d.qualities.map(q=>`<option>${q}</option>`).join('');
    showEl('vid-info');
  } else showMsg('vid-msg', d.error, 'error');
  btn.disabled=false; btn.textContent=LANGS[currentLang].btn_fetch;
}

async function startVideoDownload() {
  const url = document.getElementById('vid-url').value.trim();
  const quality = document.getElementById('vid-quality').value;
  if (!url) return showMsg('vid-msg','❌','error');
  clearMsg('vid-msg'); showEl('vid-prog');
  const d = await postJson('/api/download-video', {url, quality});
  if (d.success) trackProgress(d.dl_id,'vid-fill','vid-st','vid-pct-txt','vid-msg',s=>{
    setTxt('vid-speed',s.speed||''); setTxt('vid-eta',s.eta||'');
  });
  else { showMsg('vid-msg',d.error,'error'); hideEl('vid-prog'); }
}

// ======================== FILE DOWNLOAD ========================
async function startFileDownload() {
  const url = document.getElementById('file-url').value.trim();
  const name = document.getElementById('file-name').value.trim();
  if (!url) return showMsg('file-msg','❌','error');
  clearMsg('file-msg'); showEl('file-prog');
  const d = await postJson('/api/download-file', {url, name});
  if (d.success) trackProgress(d.dl_id,'file-fill','file-st','file-pct-txt','file-msg',s=>{
    setTxt('file-size-info', s.downloaded&&s.total?`${s.downloaded} / ${s.total}`:'');
  });
  else { showMsg('file-msg',d.error,'error'); hideEl('file-prog'); }
}

// ======================== PROGRESS ========================
function trackProgress(dlId, fillId, stId, pctId, msgId, onTick) {
  if (progressIntervals[dlId]) clearInterval(progressIntervals[dlId]);
  progressIntervals[dlId] = setInterval(async () => {
    try {
      const s = await (await fetch('/api/download-progress/'+dlId)).json();
      const pct = Math.min(100, Math.round(s.progress||0));
      document.getElementById(fillId).style.width = pct+'%';
      setTxt(pctId, pct+'%');
      setTxt(stId, s.status||'...');
      if (onTick) onTick(s);
      if (s.done) {
        clearInterval(progressIntervals[dlId]);
        showMsg(msgId,`✅ ${s.status} ${s.filename?'· '+s.filename:''} ${s.size?'· '+s.size:''}`, 'success');
        if (localStorage.getItem('notify')!=='false' && Notification.permission==='granted')
          new Notification('✅ '+(currentLang==='ar'?'اكتمل التحميل':'Download Complete'),{body:s.filename||'',icon:'/static/icons/icon-192x192.png',dir:'rtl'});
        loadStats();
      } else if (s.error) {
        clearInterval(progressIntervals[dlId]);
        showMsg(msgId,'❌ '+s.status,'error');
      }
    } catch { clearInterval(progressIntervals[dlId]); }
  }, 700);
}

// ======================== ANALYZE ========================
async function analyzeLink() {
  const url = document.getElementById('analyze-url').value.trim();
  if (!url) return showMsg('analyze-msg','❌','error');
  document.getElementById('analyze-result').style.display='none';
  showMsg('analyze-msg','⏳...','info');
  const d = await postJson('/api/analyze-link', {url});
  if (d.success) {
    const r = d.result;
    document.getElementById('result-grid').innerHTML = [
      {l:'🌐 '+(currentLang==='ar'?'النطاق':'Domain'),v:r.domain},
      {l:'🔒 '+(currentLang==='ar'?'الأمان':'Security'),v:r.secure?(currentLang==='ar'?'آمن HTTPS':'Secure HTTPS'):(currentLang==='ar'?'غير آمن':'Insecure'),c:r.secure?'ok':'warn'},
      {l:'🌍 IP',v:r.ip},{l:'📊 '+(currentLang==='ar'?'الحالة':'Status'),v:r.status_code},
      {l:'🔄 '+(currentLang==='ar'?'إعادة توجيه':'Redirects'),v:r.redirects},
      {l:'📄 '+(currentLang==='ar'?'نوع المحتوى':'Content-Type'),v:r.content_type},
      {l:'💾 '+(currentLang==='ar'?'الحجم':'Size'),v:r.content_length},
      {l:'🖥 '+(currentLang==='ar'?'الخادم':'Server'),v:r.server},
      {l:'⚡ X-Powered-By',v:r.x_powered_by},
      {l:'📅 '+(currentLang==='ar'?'آخر تعديل':'Last Modified'),v:r.last_modified},
      {l:'🔗 '+(currentLang==='ar'?'الرابط النهائي':'Final URL'),v:r.final_url},
      {l:'🌐 '+(currentLang==='ar'?'المنصة':'Platform'),v:r.platform},
    ].map(x=>`<div class="result-item ${x.c||''}"><label>${x.l}</label><span>${x.v||'—'}</span></div>`).join('');
    clearMsg('analyze-msg');
    document.getElementById('analyze-result').style.display='block';
  } else showMsg('analyze-msg',d.error,'error');
}

// ======================== FILES ========================
async function loadFiles() {
  const q = document.getElementById('file-search')?.value||'';
  const s = document.getElementById('file-sort')?.value||'date';
  const cont = document.getElementById('files-container');
  try {
    const d = await (await fetch(`/api/files?q=${encodeURIComponent(q)}&sort=${s}`)).json();
    setTxt('files-count', d.total+' '+(currentLang==='ar'?'ملف':'files'));
    if (!d.files?.length) { cont.innerHTML=`<div class="empty"><div class="ei">📂</div><p>${LANGS[currentLang].no_files}</p></div>`; return; }
    cont.innerHTML = `<div style="overflow-x:auto"><table class="data-table"><thead><tr>
      <th><input type="checkbox" onchange="toggleAllFiles(this)"></th>
      <th>${currentLang==='ar'?'الاسم':'Name'}</th><th>${currentLang==='ar'?'النوع':'Type'}</th>
      <th>${currentLang==='ar'?'الحجم':'Size'}</th><th>${currentLang==='ar'?'التاريخ':'Date'}</th>
      <th>${currentLang==='ar'?'إجراءات':'Actions'}</th>
    </tr></thead><tbody>${d.files.map(f=>`
      <tr>
        <td><input type="checkbox" value="${f.name}" class="file-cb" onchange="updateBulkBtn()"></td>
        <td style="max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;cursor:pointer" title="${f.name}" onclick="copyText('${esc(f.name)}')">${f.name}</td>
        <td><span class="type-badge ${f.type==='فيديو'?'tb-video':'tb-file'}">${f.type}</span></td>
        <td>${f.size}</td><td style="white-space:nowrap;font-size:.78em">${f.date}</td>
        <td style="display:flex;gap:4px;padding:7px 13px">
          <a href="/api/download-local/${encodeURIComponent(f.name)}" class="btn btn-info btn-sm">⬇</a>
          <button class="btn btn-ghost btn-sm" onclick="renameFile('${esc(f.name)}')">✏</button>
          <button class="btn btn-danger btn-sm" onclick="deleteFile('${esc(f.name)}',this)">🗑</button>
        </td>
      </tr>`).join('')}</tbody></table></div>`;
  } catch { cont.innerHTML='<div class="empty"><div class="ei">❌</div><p>Error</p></div>'; }
}
function toggleAllFiles(cb) { document.querySelectorAll('.file-cb').forEach(c=>c.checked=cb.checked); updateBulkBtn(); }
function updateBulkBtn() {
  const n = document.querySelectorAll('.file-cb:checked').length;
  const btn = document.getElementById('bulk-del-btn');
  btn.style.display = n>0?'inline-flex':'none';
  btn.textContent = `🗑 (${n})`;
}
async function deleteFile(name, btn) {
  if (!confirm(currentLang==='ar'?'حذف الملف؟':'Delete file?')) return;
  btn.disabled=true;
  const d = await postJson('/api/delete-file',{filename:name});
  if (d.success) { loadFiles(); showToast('🗑 '+(currentLang==='ar'?'تم الحذف':'Deleted')); }
  else { btn.disabled=false; showToast('❌'); }
}
async function bulkDelete() {
  const names = [...document.querySelectorAll('.file-cb:checked')].map(c=>c.value);
  if (!names.length || !confirm(`${currentLang==='ar'?'حذف':'Delete'} ${names.length}?`)) return;
  const d = await postJson('/api/bulk-delete',{files:names});
  showToast(`🗑 ${d.deleted}`); loadFiles();
}
async function renameFile(name) {
  const n = prompt(currentLang==='ar'?'الاسم الجديد:':'New name:', name);
  if (!n||n===name) return;
  const d = await postJson('/api/rename-file',{old_name:name,new_name:n});
  if (d.success) { showToast('✅'); loadFiles(); } else showToast('❌');
}

// ======================== QR ========================
async function generateQR() {
  const text = document.getElementById('qr-text').value.trim();
  if (!text) return showMsg('qr-gen-msg','❌','error');
  showMsg('qr-gen-msg','⏳...','info');
  document.getElementById('qr-gen-result').style.display='none';
  const d = await postJson('/api/qr-generate',{text,color:document.getElementById('qr-color').value,bg_color:document.getElementById('qr-bg').value,size:parseInt(document.getElementById('qr-size').value)});
  if (d.success) {
    document.getElementById('qr-img').src=d.image;
    document.getElementById('qr-dl').href=d.image;
    document.getElementById('qr-gen-result').style.display='block';
    clearMsg('qr-gen-msg');
  } else showMsg('qr-gen-msg',d.error,'error');
}

let qrResult = '';
function readQR(input) {
  const file = input.files[0]; if (!file) return;
  document.getElementById('qr-read-result').style.display='none';
  showMsg('qr-read-msg','⏳...','info');
  const reader = new FileReader();
  reader.onload = e => {
    const dataUrl = e.target.result;
    document.getElementById('qr-prev-img').src=dataUrl;
    document.getElementById('qr-read-preview').style.display='block';
    const img = new Image();
    img.onload = () => {
      const canvas = document.getElementById('qr-canvas');
      canvas.width=img.width; canvas.height=img.height;
      canvas.getContext('2d').drawImage(img,0,0);
      const imgData = canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height);
      const code = jsQR(imgData.data,imgData.width,imgData.height,{inversionAttempts:'dontInvert'})
        || jsQR(imgData.data,imgData.width,imgData.height,{inversionAttempts:'onlyInvert'});
      if (code) {
        qrResult = code.data;
        setTxt('qr-decoded', code.data);
        document.getElementById('qr-open-btn').style.display=/^https?:\/\//i.test(code.data)?'inline-flex':'none';
        document.getElementById('qr-read-result').style.display='block';
        clearMsg('qr-read-msg');
      } else showMsg('qr-read-msg','⚠️ '+(currentLang==='ar'?'لم يتم العثور على باركود':'No QR code found'),'error');
    };
    img.src=dataUrl;
  };
  reader.readAsDataURL(file);
  input.value='';
}

// Drag & drop
['qr-drop','img-drop'].forEach(id => {
  const zone = document.getElementById(id);
  if (!zone) return;
  zone.addEventListener('dragover', e=>{e.preventDefault();zone.style.borderColor='var(--accent)'});
  zone.addEventListener('dragleave', ()=>zone.style.borderColor='');
  zone.addEventListener('drop', e=>{
    e.preventDefault(); zone.style.borderColor='';
    const f = e.dataTransfer.files[0];
    if (!f||!f.type.startsWith('image/')) return;
    const dt = new DataTransfer(); dt.items.add(f);
    const inp = document.getElementById(id==='qr-drop'?'qr-file':'img-file');
    inp.files = dt.files;
    id==='qr-drop' ? readQR(inp) : previewImg(inp);
  });
});

// ======================== TEXT TOOLS ========================
async function encode(mode) {
  const text = document.getElementById('enc-input').value;
  if (!text) return;
  const d = await postJson('/api/encode-decode',{text,mode});
  if (d.success) { document.getElementById('enc-output').textContent=d.result; document.getElementById('enc-result').style.display='block'; clearMsg('enc-msg'); }
  else showMsg('enc-msg',d.error,'error');
}
async function genHash() {
  const text = document.getElementById('hash-input').value;
  if (!text) return;
  const d = await postJson('/api/hash-text',{text});
  if (d.success) {
    document.getElementById('hash-result').style.display='block';
    document.getElementById('hash-result').innerHTML = Object.entries(d.results).map(([k,v])=>`
      <div class="hash-row">
        <div class="hash-label">${k}</div>
        <div class="hash-val" onclick="copyText('${v}')" title="${currentLang==='ar'?'انقر للنسخ':'Click to copy'}">${v}</div>
      </div>`).join('');
    clearMsg('hash-msg');
  } else showMsg('hash-msg',d.error,'error');
}
function genPassword() {
  const len = parseInt(document.getElementById('pw-len').value)||16;
  let chars='';
  if (document.getElementById('pw-upper').checked) chars+='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  if (document.getElementById('pw-lower').checked) chars+='abcdefghijklmnopqrstuvwxyz';
  if (document.getElementById('pw-nums').checked) chars+='0123456789';
  if (document.getElementById('pw-syms').checked) chars+='!@#$%^&*()_+-=[]{}|;:,.?';
  if (!chars) return;
  let pw=''; for(let i=0;i<len;i++) pw+=chars[Math.floor(Math.random()*chars.length)];
  setTxt('pw-val',pw); document.getElementById('pw-result').style.display='block';
  const s=pw.length>=16&&/[A-Z]/.test(pw)&&/[0-9]/.test(pw)&&/[^a-zA-Z0-9]/.test(pw)?'✅ قوية جداً':pw.length>=12?'🟢 قوية':pw.length>=8?'🟡 متوسطة':'🔴 ضعيفة';
  setTxt('pw-strength',s);
}

// ======================== IMAGE TOOLS ========================
function previewImg(input) {
  const file=input.files[0]; if(!file) return;
  window._currentImgFile=file;
  const reader=new FileReader();
  reader.onload=e=>{
    document.getElementById('img-preview').src=e.target.result;
    document.getElementById('img-preview-wrap').style.display='block';
    document.getElementById('img-ops').style.display='flex';
    setTxt('img-info',`${file.name} · ${(file.size/1024).toFixed(1)} KB`);
  };
  reader.readAsDataURL(file);
}
async function applyOp(op) {
  if(!window._currentImgFile) return showMsg('img-msg','❌','error');
  showMsg('img-msg','⏳...','info');
  const form=new FormData();
  form.append('file',window._currentImgFile);
  form.append('op',op);
  if(op==='rotate') form.append('angle','90');
  if(op==='brightness'||op==='contrast') form.append('factor','1.5');
  try {
    const d=await (await fetch('/api/image-process',{method:'POST',body:form})).json();
    if(d.success&&d.image){
      document.getElementById('img-result-wrap').innerHTML=`
        <img src="${d.image}" class="img-preview" alt="">
        <div style="font-size:.75em;color:var(--muted);text-align:center;margin-top:5px">${d.width}×${d.height}px</div>
        <div style="text-align:center;margin-top:9px">
          <a href="${d.image}" download="result.png" class="btn btn-success btn-sm">⬇ ${LANGS[currentLang].btn_download}</a>
        </div>`;
      clearMsg('img-msg');
    } else if(d.info){
      document.getElementById('img-result-wrap').innerHTML='<div class="result-grid">'+Object.entries(d.info).map(([k,v])=>`<div class="result-item"><label>${k}</label><span>${v}</span></div>`).join('')+'</div>';
      clearMsg('img-msg');
    } else showMsg('img-msg',d.error,'error');
  } catch(e){showMsg('img-msg','❌'+e.message,'error');}
}

// ======================== NETWORK ========================
async function lookupIP() {
  const target = document.getElementById('ip-input').value.trim();
  if(!target) return showMsg('ip-msg','❌','error');
  showMsg('ip-msg','⏳...','info');
  document.getElementById('ip-result').style.display='none';
  const d = await postJson('/api/ip-lookup',{target});
  if(d.success){
    document.getElementById('ip-grid').innerHTML=
      `<div class="result-item"><label>IP</label><span>${d.ip}</span></div>`+
      Object.entries(d.data).map(([k,v])=>`<div class="result-item"><label>${k}</label><span>${v||'—'}</span></div>`).join('');
    document.getElementById('ip-result').style.display='block';

    // Google Maps section
    const mapsSection = document.getElementById('ip-maps-section');
    if(d.maps_url && d.lat && d.lon){
      document.getElementById('ip-coords').textContent = `${d.lat}, ${d.lon}`;
      document.getElementById('ip-maps-link').href = d.maps_url;
      mapsSection.style.display='block';
    } else {
      mapsSection.style.display='none';
    }
    clearMsg('ip-msg');
  } else showMsg('ip-msg',d.error,'error');
}

async function doPing() {
  const host=document.getElementById('ping-input').value.trim();
  if(!host) return showMsg('ping-msg','❌','error');
  const btn=document.getElementById('ping-btn');
  btn.disabled=true; btn.innerHTML='<span class="loader"></span>';
  showMsg('ping-msg','⏳...','info');
  document.getElementById('ping-result').style.display='none';
  const d=await postJson('/api/ping',{host});
  btn.disabled=false; btn.innerHTML='📡 Ping';
  if(d.success){
    document.getElementById('ping-packets').innerHTML=d.results.map(r=>
      `<div style="display:flex;align-items:center;gap:9px">
        <span style="color:var(--muted);font-size:.78em">#${r.seq}</span>
        <span class="ping-result ${r.status==='ok'?'ping-ok':'ping-fail'}">${r.status==='ok'?r.ms+' ms':'timeout'}</span>
        ${r.ip?`<span style="font-size:.72em;color:var(--muted)">${r.ip}</span>`:''}
      </div>`).join('');
    document.getElementById('ping-summary').innerHTML=
      `<b>${d.host}</b> &nbsp;|&nbsp; Avg: <b style="color:#34d399">${d.avg_ms?d.avg_ms+' ms':'—'}</b> &nbsp;|&nbsp; Loss: <b style="color:${d.packet_loss>0?'#fca5a5':'#34d399'}">${d.packet_loss}%</b>`;
    document.getElementById('ping-result').style.display='block';
    clearMsg('ping-msg');
  } else showMsg('ping-msg',d.error,'error');
}

async function doHead() {
  const url=document.getElementById('head-url').value.trim();
  if(!url) return showMsg('head-msg','❌','error');
  showMsg('head-msg','⏳...','info');
  document.getElementById('head-result').style.display='none';
  const d=await postJson('/api/analyze-link',{url});
  if(d.success){
    const r=d.result;
    document.getElementById('head-grid').innerHTML=[
      {l:'💾 '+(currentLang==='ar'?'الحجم':'Size'),v:r.content_length},
      {l:'📄 '+(currentLang==='ar'?'النوع':'Type'),v:r.content_type},
      {l:'🖥 '+(currentLang==='ar'?'الخادم':'Server'),v:r.server},
      {l:'📊 Status',v:r.status_code},
      {l:'🔄 '+(currentLang==='ar'?'إعادة توجيه':'Redirects'),v:r.redirects},
      {l:'📅 '+(currentLang==='ar'?'آخر تعديل':'Last Modified'),v:r.last_modified},
    ].map(x=>`<div class="result-item"><label>${x.l}</label><span>${x.v||'—'}</span></div>`).join('');
    document.getElementById('head-result').style.display='block';
    clearMsg('head-msg');
  } else showMsg('head-msg',d.error,'error');
}

// ======================== NOTES ========================
async function loadNotes(){
  const d=await (await fetch('/api/notes')).json();
  const grid=document.getElementById('notes-grid');
  if(!d.notes?.length){grid.innerHTML=`<div class="empty" style="grid-column:1/-1"><div class="ei">📝</div><p>${LANGS[currentLang].no_notes}</p></div>`;return;}
  grid.innerHTML=d.notes.map(n=>`
    <div class="note-card" style="background:${n.color}1a;border:1px solid ${n.color}44">
      <button class="note-del" onclick="deleteNote(${n.id})">✕</button>
      ${n.title?`<h4>${n.title}</h4>`:''}
      <p>${n.content.replace(/\n/g,'<br>').replace(/https?:\/\/\S+/g,m=>`<a href="${m}" target="_blank" style="color:#93c5fd;word-break:break-all">${m}</a>`)}</p>
      <div class="note-footer"><span>${n.created}</span></div>
    </div>`).join('');
}
async function addNote(){
  const title=document.getElementById('note-title').value.trim();
  const content=document.getElementById('note-content').value.trim();
  const color=document.getElementById('note-color').value;
  if(!content) return showMsg('note-msg','❌','error');
  const d=await postJson('/api/notes',{title,content,color});
  if(d.success){document.getElementById('note-title').value='';document.getElementById('note-content').value='';clearMsg('note-msg');loadNotes();showToast('✅');}
  else showMsg('note-msg',d.error,'error');
}
async function deleteNote(id){await fetch('/api/notes/'+id,{method:'DELETE'});loadNotes();}

// ======================== PLATFORMS ========================
const PLATFORMS={
  'يوتيوب':'🎬','تيك توك':'📱','انستغرام':'📸','فيسبوك':'👥','تويتر / X':'🐦',
  'ريديت':'🤖','تويتش':'🎮','فيميو':'🎥','دايلي موشن':'▶','VK':'💬','OK.ru':'👌',
  'بيليبيلي':'📺','لينكد إن':'💼','سناب شات':'👻','ساوند كلاود':'🎵','ميكسكلاود':'🎧',
  'بوديان':'🎙','تمبلر':'📓','يوتيوب ميوزيك':'🎵',
};
function buildPlatforms(){
  ['all-platforms','vid-platforms'].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.innerHTML=Object.entries(PLATFORMS).map(([n,i])=>`<div class="platform-card"><span class="pc-icon">${i}</span>${n}</div>`).join('');
  });
}

// ======================== SETTINGS ========================
async function loadSettings(){
  try{
    const d=await (await fetch('/api/settings')).json();
    const s=d.settings;
    if(s.accent_color){previewAccent(s.accent_color);const el=document.getElementById('accent-color');if(el)el.value=s.accent_color;}
    if(s.default_quality){const el=document.getElementById('def-quality');if(el)el.value=s.default_quality;}
    document.getElementById('set-notify').checked=s.notify_on_complete!==false;
    document.getElementById('set-autodetect').checked=s.auto_detect!==false;
    document.getElementById('set-history').checked=s.save_history!==false;
    document.getElementById('set-thumbs').checked=s.show_thumbnails!==false;
    const info=await (await fetch('/api/app-info')).json();
    const grid=document.getElementById('app-info-grid');
    if(grid) grid.innerHTML=[
      {l:'🌐 '+(currentLang==='ar'?'المنصات':'Platforms'),v:info.platforms_count},
      {l:'📥 '+(currentLang==='ar'?'الجودة الافتراضية':'Default Quality'),v:info.default_quality},
      {l:'🔔 '+(currentLang==='ar'?'الإشعارات':'Notifications'),v:info.notify_on_complete?(currentLang==='ar'?'مفعّلة':'Enabled'):(currentLang==='ar'?'معطّلة':'Disabled')},
      {l:'📲 PWA',v:window.matchMedia('(display-mode: standalone)').matches?(currentLang==='ar'?'مثبّت':'Installed'):(currentLang==='ar'?'متصفح':'Browser')},
    ].map(x=>`<div class="result-item"><label>${x.l}</label><span>${x.v}</span></div>`).join('');
  }catch{}
}
async function saveAppSettings(){
  const d=await postJson('/api/settings',{accent_color:document.getElementById('accent-color').value,default_quality:document.getElementById('def-quality').value});
  showMsg('theme-msg',d.success?'✅ '+d.message:d.error,d.success?'success':'error');
}
async function saveAdvancedSettings(){
  const notify=document.getElementById('set-notify').checked;
  localStorage.setItem('notify',notify);
  if(notify&&Notification.permission!=='granted') Notification.requestPermission();
  const d=await postJson('/api/settings',{notify_on_complete:notify,auto_detect:document.getElementById('set-autodetect').checked,save_history:document.getElementById('set-history').checked,show_thumbnails:document.getElementById('set-thumbs').checked});
  showMsg('adv-msg',d.success?'✅ '+d.message:d.error,d.success?'success':'error');
}
async function changeCode(){
  const cur=document.getElementById('cur-code').value;
  const nw=document.getElementById('new-code').value;
  const nw2=document.getElementById('new-code2').value;
  if(nw!==nw2) return showMsg('code-msg',currentLang==='ar'?'الرمزان غير متطابقان':'Codes do not match','error');
  if(nw.length<4) return showMsg('code-msg',currentLang==='ar'?'الرمز قصير جداً':'Code too short','error');
  const d=await postJson('/api/settings',{current_code:cur,new_code:nw});
  showMsg('code-msg',d.success?'✅ '+(currentLang==='ar'?'تم التغيير':'Changed'):d.error,d.success?'success':'error');
  if(d.success){['cur-code','new-code','new-code2'].forEach(id=>document.getElementById(id).value='');}
}
async function resetSettings(){
  if(!confirm(currentLang==='ar'?'إعادة ضبط كل الإعدادات؟':'Reset all settings?')) return;
  await fetch('/api/settings/reset',{method:'POST'});
  showToast('✅');loadSettings();
}
async function clearHistory(){
  if(!confirm(currentLang==='ar'?'مسح السجل؟':'Clear history?')) return;
  await fetch('/api/clear-history',{method:'POST'});
  showToast('🗑');loadStats();
}

// ======================== WEATHER ========================
async function fetchWeather(){
  const city=document.getElementById('city-input').value.trim();
  if(!city){showMsg('weather-msg','أدخل اسم المدينة','error');return;}
  const btn=document.getElementById('weather-btn');
  btn.disabled=true;btn.textContent='⏳ جاري البحث...';
  clearMsg('weather-msg');
  const r=await postJson('/api/weather',{city});
  btn.disabled=false;btn.textContent='🔍 بحث';
  if(r.error){showMsg('weather-msg',r.error,'error');return;}
  const d=r.data;
  document.getElementById('w-emoji').textContent=d.emoji;
  document.getElementById('w-city').textContent=d.city;
  document.getElementById('w-temp').textContent=`${d.temp_c}°C / ${d.temp_f}°F`;
  document.getElementById('w-desc').textContent=d.desc;
  const details=[
    {icon:'💧',label:'رطوبة',val:d.humidity+'%'},
    {icon:'💨',label:'رياح',val:d.wind_kmph+' km/h '+d.wind_dir},
    {icon:'👁',label:'رؤية',val:d.visibility+' km'},
    {icon:'🌡',label:'الإحساس',val:d.feels_c+'°C'},
    {icon:'🔵',label:'ضغط',val:d.pressure+' mb'},
    {icon:'☀',label:'UV',val:d.uv},
  ];
  document.getElementById('w-details').innerHTML=details.map(x=>
    `<div style="background:rgba(255,255,255,.05);border-radius:10px;padding:10px;text-align:center">
      <div style="font-size:1.4em">${x.icon}</div>
      <div style="font-size:.7em;color:var(--muted);margin:2px 0">${x.label}</div>
      <div style="font-size:.85em;color:#fff;font-weight:600">${x.val}</div>
    </div>`
  ).join('');
  const days=['اليوم','غداً','بعده'];
  document.getElementById('w-forecast').innerHTML=(d.forecast||[]).map((f,i)=>
    `<div style="background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:12px;padding:12px;text-align:center">
      <div style="font-size:.75em;color:var(--muted);margin-bottom:6px">${days[i]||f.date}</div>
      <div style="font-size:1.8em;margin-bottom:4px">${f.emoji}</div>
      <div style="font-size:.82em;color:#a78bfa;font-weight:600">${f.max_c}° / ${f.min_c}°</div>
      <div style="font-size:.72em;color:var(--muted);margin-top:3px">${f.desc}</div>
    </div>`
  ).join('');
  document.getElementById('weather-result').style.display='block';
}
function setCityAndFetch(city){document.getElementById('city-input').value=city;fetchWeather();}

// ======================== WORLD CLOCK ========================
const CLOCKS=[
  {city:'الرياض',tz:'Asia/Riyadh',flag:'🇸🇦'},
  {city:'القاهرة',tz:'Africa/Cairo',flag:'🇪🇬'},
  {city:'دبي',tz:'Asia/Dubai',flag:'🇦🇪'},
  {city:'لندن',tz:'Europe/London',flag:'🇬🇧'},
  {city:'نيويورك',tz:'America/New_York',flag:'🇺🇸'},
  {city:'طوكيو',tz:'Asia/Tokyo',flag:'🇯🇵'},
  {city:'باريس',tz:'Europe/Paris',flag:'🇫🇷'},
  {city:'سيدني',tz:'Australia/Sydney',flag:'🇦🇺'},
];
function initWorldClock(){
  const container=document.getElementById('world-clock');
  if(!container)return;
  function update(){
    const now=new Date();
    container.innerHTML=CLOCKS.map(c=>{
      const time=now.toLocaleTimeString('ar-SA',{timeZone:c.tz,hour:'2-digit',minute:'2-digit',second:'2-digit'});
      const date=now.toLocaleDateString('ar-SA',{timeZone:c.tz,weekday:'short',month:'short',day:'numeric'});
      return `<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:rgba(255,255,255,.04);border-radius:10px;border:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:1.3em">${c.flag}</span>
          <div><div style="font-size:.85em;color:#fff;font-weight:600">${c.city}</div><div style="font-size:.7em;color:var(--muted)">${date}</div></div>
        </div>
        <div style="font-family:monospace;color:#a78bfa;font-weight:700;font-size:.95em;direction:ltr">${time}</div>
      </div>`;
    }).join('');
  }
  update();setInterval(update,1000);
}

async function loadTimestamp(){
  const r=await fetch('/api/timestamp');const d=await r.json();
  const fields=[
    ['Unix Timestamp',d.unix],['Unix (ms)',d.unix_ms],
    ['ISO 8601',d.iso],['UTC',d.utc],
    ['التاريخ',d.date],['الوقت',d.time],
    ['اليوم',d.day],['الأسبوع',d.week],
  ];
  document.getElementById('timestamp-info').innerHTML=fields.map(([k,v])=>
    `<div style="background:rgba(255,255,255,.04);border-radius:8px;padding:8px">
      <div style="font-size:.7em;color:var(--muted);margin-bottom:3px">${k}</div>
      <div style="font-size:.82em;color:#fff;font-family:monospace;direction:ltr">${v}</div>
    </div>`
  ).join('');
}

async function loadQuote(){
  document.getElementById('quote-text').textContent='جاري التحميل...';
  document.getElementById('quote-author').textContent='—';
  const r=await fetch('/api/random-quote');const d=await r.json();
  if(d.success){
    document.getElementById('quote-text').textContent='"'+d.quote+'"';
    document.getElementById('quote-author').textContent='— '+d.author;
  }
}

// ======================== CURRENCY ========================
const ALL_CURRENCIES=['AED','AFN','ALL','AMD','ANG','AOA','ARS','AUD','AWG','AZN','BAM','BBD','BDT','BGN','BHD','BIF','BMD','BND','BOB','BRL','BSD','BTN','BWP','BZD','CAD','CDF','CHF','CLP','CNY','COP','CRC','CVE','CZK','DJF','DKK','DOP','DZD','EGP','ERN','ETB','EUR','FJD','FKP','GBP','GEL','GHS','GIP','GMD','GNF','GTQ','GYD','HKD','HNL','HRK','HTG','HUF','IDR','ILS','INR','IQD','IRR','ISK','JMD','JOD','JPY','KES','KGS','KHR','KMF','KPW','KRW','KWD','KYD','KZT','LAK','LBP','LKR','LRD','LSL','LYD','MAD','MDL','MGA','MKD','MMK','MNT','MOP','MRO','MUR','MVR','MWK','MXN','MYR','MZN','NAD','NGN','NIO','NOK','NPR','NZD','OMR','PAB','PEN','PGK','PHP','PKR','PLN','PYG','QAR','RON','RSD','RUB','RWF','SAR','SBD','SCR','SDG','SEK','SGD','SHP','SLL','SOS','SRD','STD','SVC','SYP','SZL','THB','TJS','TMT','TND','TOP','TRY','TTD','TWD','TZS','UAH','UGX','USD','UYU','UZS','VEF','VND','VUV','WST','XAF','XOF','YER','ZAR','ZMW'];
function populateCurrencySelects(){
  const common=['USD','EUR','GBP','SAR','AED','EGP','KWD','QAR','BHD','OMR','JOD','MAD','DZD','TND','LYD','TRY','JPY','CNY','INR','MYR','NGN','ZAR'];
  const sorted=[...common,...ALL_CURRENCIES.filter(c=>!common.includes(c))];
  ['cur-from','cur-to','rates-base'].forEach((id,i)=>{
    const el=document.getElementById(id);if(!el)return;
    el.innerHTML=sorted.map(c=>`<option value="${c}">${c}</option>`).join('');
    if(id==='cur-from')el.value='USD';
    if(id==='cur-to')el.value='SAR';
    if(id==='rates-base')el.value='USD';
  });
}
async function convertCurrency(){
  const amount=document.getElementById('cur-amount').value||1;
  const from=document.getElementById('cur-from').value;
  const to=document.getElementById('cur-to').value;
  clearMsg('cur-msg');
  if(from===to){
    document.getElementById('cur-output').textContent=`${amount} ${to}`;
    document.getElementById('cur-rate-info').textContent='نفس العملة';
    document.getElementById('cur-result').style.display='block';return;
  }
  showMsg('cur-msg','جاري التحويل...','info');
  const r=await postJson('/api/currency',{amount,from,to});
  clearMsg('cur-msg');
  if(r.error){showMsg('cur-msg',r.error,'error');return;}
  document.getElementById('cur-output').textContent=`${r.result.toLocaleString()} ${to}`;
  document.getElementById('cur-rate-info').textContent=`1 ${from} = ${r.rate} ${to} · ${r.date}`;
  document.getElementById('cur-result').style.display='block';
}
async function loadRates(){
  const base=document.getElementById('rates-base').value;
  showMsg('rates-msg','جاري التحديث...','info');
  const r=await postJson('/api/currency-rates',{base});
  clearMsg('rates-msg');
  if(r.error){showMsg('rates-msg',r.error,'error');return;}
  document.getElementById('rates-base-lbl').textContent=base;
  document.getElementById('rates-grid').innerHTML=Object.entries(r.rates)
    .sort((a,b)=>a[0].localeCompare(b[0]))
    .map(([code,rate])=>
      `<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:rgba(255,255,255,.04);border-radius:8px;border:1px solid var(--border);cursor:pointer" onclick="document.getElementById('cur-to').value='${code}';document.getElementById('cur-from').value='${base}';convertCurrency()">
        <span style="font-weight:600;color:#a78bfa;font-size:.85em">${code}</span>
        <span style="font-family:monospace;color:#fff;font-size:.82em">${Number(rate).toLocaleString(undefined,{maximumFractionDigits:4})}</span>
      </div>`
    ).join('');
}

// ======================== BATCH DOWNLOAD ========================
let batchData=[];
async function analyzeBatch(){
  const raw=document.getElementById('batch-urls').value;
  const urls=raw.split('\n').map(u=>u.trim()).filter(u=>u);
  if(!urls.length){showMsg('batch-msg','الصق روابط أولاً','error');return;}
  showMsg('batch-msg','⏳ جاري تحليل الروابط...','info');
  document.getElementById('batch-dl-btn').style.display='none';
  const r=await postJson('/api/batch-analyze',{urls});
  clearMsg('batch-msg');
  if(r.error){showMsg('batch-msg',r.error,'error');return;}
  batchData=r.results;
  const container=document.getElementById('batch-list');
  container.innerHTML=batchData.map((item,i)=>`
    <div style="background:rgba(255,255,255,.04);border:1px solid ${item.valid?'rgba(124,58,237,.25)':'rgba(239,68,68,.2)'};border-radius:12px;padding:14px;display:flex;align-items:center;gap:12px">
      <input type="checkbox" id="batch-chk-${i}" ${item.valid?'checked':''} style="width:18px;height:18px;cursor:pointer">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
          <span style="background:rgba(124,58,237,.2);color:#a78bfa;padding:2px 8px;border-radius:20px;font-size:.72em;font-weight:600">${item.platform}</span>
          <span style="font-size:.72em;color:var(--muted)">${item.type==='video'?'🎬':'📄'} ${item.type}</span>
          ${item.size&&item.size!='—'?`<span style="font-size:.72em;color:var(--muted)">💾 ${item.size}</span>`:''}
          <span style="margin-right:auto;font-size:.72em;color:${item.valid?'#34d399':'#f87171'}">${item.valid?'✅ صالح':'❌ غير صالح'}</span>
        </div>
        <div style="font-size:.78em;color:var(--muted);direction:ltr;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${item.url}</div>
      </div>
    </div>
  `).join('');
  document.getElementById('batch-results').style.display='block';
  document.getElementById('batch-dl-btn').style.display='flex';
}
async function startBatch(){
  const quality=document.getElementById('batch-quality').value;
  const items=batchData.filter((_,i)=>{const el=document.getElementById('batch-chk-'+i);return el&&el.checked;})
    .map(item=>({url:item.url,type:item.type,quality}));
  if(!items.length){showMsg('batch-msg','اختر روابط أولاً','error');return;}
  showMsg('batch-msg','⏳ جاري بدء التحميل...','info');
  const r=await postJson('/api/batch-start',{items});
  if(r.error){showMsg('batch-msg',r.error,'error');return;}
  showMsg('batch-msg',`✅ بدأ تحميل ${r.started.length} عنصر — راجع تتبع التحميلات النشطة`,'success');
  setTimeout(()=>{go('home');},2000);
}

// ======================== URL SHORTENER ========================
let shortHistory=JSON.parse(localStorage.getItem('shortHistory')||'[]');
async function shortenURL(){
  const url=document.getElementById('shorten-url').value.trim();
  if(!url){showMsg('shorten-msg','أدخل رابطاً','error');return;}
  clearMsg('shorten-msg');showMsg('shorten-msg','⏳ جاري الاختصار...','info');
  const r=await postJson('/api/shorten-url',{url});
  clearMsg('shorten-msg');
  if(r.error){showMsg('shorten-msg',r.error,'error');return;}
  document.getElementById('short-link').textContent=r.short;
  document.getElementById('short-link').href=r.short;
  document.getElementById('short-service').textContent='via '+r.service;
  document.getElementById('shorten-result').style.display='block';
  document.getElementById('short-qr').style.display='none';
  shortHistory.unshift({short:r.short,original:url,service:r.service,date:new Date().toLocaleString('ar-SA')});
  shortHistory=shortHistory.slice(0,20);
  localStorage.setItem('shortHistory',JSON.stringify(shortHistory));
  renderShortHistory();
}
function renderShortHistory(){
  const el=document.getElementById('short-history');
  if(!shortHistory.length){el.innerHTML='<div class="empty"><div class="ei">🔗</div><p>لا يوجد سجل</p></div>';return;}
  el.innerHTML=shortHistory.map((h,i)=>`
    <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:10px;border:1px solid var(--border)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px">
        <a href="${h.short}" target="_blank" style="color:#34d399;font-weight:600;font-size:.88em;direction:ltr">${h.short}</a>
        <button class="btn btn-ghost btn-sm" onclick="copyText('${h.short}')">📋</button>
      </div>
      <div style="font-size:.72em;color:var(--muted);direction:ltr;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${h.original}</div>
      <div style="font-size:.7em;color:var(--muted);margin-top:3px">${h.date} · ${h.service}</div>
    </div>
  `).join('');
}
async function genShortQR(){
  const url=document.getElementById('short-link').textContent;
  if(!url)return;
  const r=await postJson('/api/qr-generate',{url,color:'#7c3aed',bg:'#0f0f1a',size:150});
  if(r.success){
    document.getElementById('short-qr-img').src='data:image/png;base64,'+r.image;
    document.getElementById('short-qr').style.display='block';
  }
}

// ======================== CALCULATOR ========================
let calcExpr='',calcPrev='',calcDone=false;
function calcInput(val){
  if(calcDone&&!isNaN(val)){calcExpr='';calcPrev='';}
  calcDone=false;calcExpr+=val;
  document.getElementById('calc-display').textContent=calcExpr||'0';
  document.getElementById('calc-expr').textContent=calcPrev;
}
function calcEval(){
  if(!calcExpr)return;
  try{
    const safe=calcExpr.replace(/[^0-9+\-*/.()%MathsqrcotanpiPIE ]/g,'');
    // eslint-disable-next-line no-new-func
    const res=Function('"use strict";return('+safe+')')();
    const out=Number.isFinite(res)?+res.toPrecision(12):res;
    const h=document.getElementById('calc-history');
    h.innerHTML=`<div>${calcExpr} = <b>${out}</b></div>`+h.innerHTML;
    calcPrev=calcExpr+'=';
    document.getElementById('calc-display').textContent=out;
    document.getElementById('calc-expr').textContent=calcPrev;
    calcExpr=String(out);calcDone=true;
  }catch{document.getElementById('calc-display').textContent='خطأ';}
}
function calcClear(){calcExpr='';calcPrev='';calcDone=false;document.getElementById('calc-display').textContent='0';document.getElementById('calc-expr').textContent='';}
function calcDel(){if(calcDone){calcClear();return;}calcExpr=calcExpr.slice(0,-1);document.getElementById('calc-display').textContent=calcExpr||'0';}
function calcSci(pre,post){
  if(calcDone){calcExpr='';calcPrev='';}calcDone=false;
  const cur=calcExpr||'0';calcExpr=pre+cur+post;
  try{
    const res=Function('"use strict";return('+calcExpr+')')();
    const out=+Number(res).toPrecision(12);
    const h=document.getElementById('calc-history');
    h.innerHTML=`<div>${calcExpr} = <b>${out}</b></div>`+h.innerHTML;
    document.getElementById('calc-display').textContent=out;
    document.getElementById('calc-expr').textContent=calcExpr+'=';
    calcExpr=String(out);calcDone=true;
  }catch{document.getElementById('calc-display').textContent='خطأ';}
}

// ======================== UNIT CONVERTER ========================
const UNITS={
  length:{م:[1],'سم':[0.01],'مم':[0.001],'كم':[1000],'ميل':[1609.34],'قدم':[0.3048],'بوصة':[0.0254],'يارد':[0.9144]},
  weight:{كغ:[1],'غ':[0.001],'ملغ':[0.000001],'طن':[1000],'باوند':[0.453592],'أوقية':[0.0283495]},
  temp:{مئوية:[1,0,'°C'],فهرنهايت:[null,null,'°F'],كلفن:[null,null,'K']},
  area:{'م²':[1],'سم²':[0.0001],'كم²':[1e6],'هكتار':[10000],'فدان':[4046.86],'قدم²':[0.0929030],'ميل²':[2589988]},
  speed:{'م/ث':[1],'كم/ساعة':[0.277778],'ميل/ساعة':[0.44704],'عقدة':[0.514444]},
  data:{'بايت':[1],'كيلوبايت':[1024],'ميغابايت':[1048576],'غيغابايت':[1073741824],'تيرابايت':[1.0995e12],'بيت':[0.125]},
};
let curUnitCat='length';
function setUnitCat(cat){
  curUnitCat=cat;
  document.querySelectorAll('#unit-cats .btn').forEach((b,i)=>{b.className='btn btn-ghost btn-sm';if(i===['length','weight','temp','area','speed','data'].indexOf(cat))b.className='btn btn-primary btn-sm';});
  const units=Object.keys(UNITS[cat]);
  ['unit-from','unit-to'].forEach((id,i)=>{
    const el=document.getElementById(id);
    el.innerHTML=units.map(u=>`<option>${u}</option>`).join('');
    if(i===1&&units.length>1)el.selectedIndex=1;
  });
  convertUnit();
}
function convertUnit(){
  const val=parseFloat(document.getElementById('unit-val').value)||0;
  const from=document.getElementById('unit-from').value;
  const to=document.getElementById('unit-to').value;
  let res;
  if(curUnitCat==='temp'){
    let c;
    if(from==='مئوية')c=val;
    else if(from==='فهرنهايت')c=(val-32)*5/9;
    else c=val-273.15;
    if(to==='مئوية')res=c;
    else if(to==='فهرنهايت')res=c*9/5+32;
    else res=c+273.15;
  }else{
    const factors=UNITS[curUnitCat];
    const fromF=factors[from]?.[0]||1;
    const toF=factors[to]?.[0]||1;
    res=val*fromF/toF;
  }
  const formatted=Math.abs(res)<0.001||Math.abs(res)>1e9?res.toExponential(4):+res.toPrecision(8);
  document.getElementById('unit-output').textContent=`${formatted} ${to}`;
}

// ======================== JSON FORMATTER ========================
function formatJSON(){
  const inp=document.getElementById('json-input').value.trim();
  if(!inp){showMsg('json-msg','أدخل JSON','error');return;}
  try{
    const parsed=JSON.parse(inp);
    document.getElementById('json-output').textContent=JSON.stringify(parsed,null,2);
    showMsg('json-msg','✅ صالح وتم التنسيق','success');
  }catch(e){document.getElementById('json-output').textContent='خطأ: '+e.message;showMsg('json-msg','❌ JSON غير صالح: '+e.message,'error');}
}
function minifyJSON(){
  const inp=document.getElementById('json-input').value.trim();
  try{document.getElementById('json-output').textContent=JSON.stringify(JSON.parse(inp));showMsg('json-msg','✅ تم الضغط','success');}
  catch(e){showMsg('json-msg','❌ '+e.message,'error');}
}
function validateJSON(){
  try{JSON.parse(document.getElementById('json-input').value);showMsg('json-msg','✅ JSON صالح تماماً','success');}
  catch(e){showMsg('json-msg','❌ '+e.message,'error');}
}

// ======================== REGEX TESTER ========================
function testRegex(){
  const pat=document.getElementById('regex-pattern').value;
  const text=document.getElementById('regex-text').value;
  const flags=document.getElementById('regex-flags').value;
  clearMsg('regex-msg');
  if(!pat){document.getElementById('regex-result').style.display='none';return;}
  try{
    const re=new RegExp(pat,flags);
    const matches=[...text.matchAll(new RegExp(pat,flags.includes('g')?flags:flags+'g'))];
    let highlighted=text.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
    if(matches.length){
      highlighted=highlighted.replace(new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),flags.includes('g')?flags:flags+'g'),
        m=>`<mark style="background:#7c3aed;color:#fff;border-radius:3px;padding:0 2px">${m}</mark>`);
    }
    document.getElementById('regex-highlighted').innerHTML=highlighted||'<span style="color:var(--muted)">النص يظهر هنا...</span>';
    document.getElementById('regex-matches').innerHTML=matches.length
      ?`<span style="color:#34d399">✅ ${matches.length} تطابق</span>`+
        (matches.length<=10?': '+matches.map(m=>`<code style="background:rgba(124,58,237,.2);padding:1px 5px;border-radius:4px;color:#a78bfa">${m[0]}</code>`).join(' '):'')
      :`<span style="color:#f87171">لا يوجد تطابق</span>`;
    document.getElementById('regex-result').style.display='block';
  }catch(e){showMsg('regex-msg','❌ خطأ في النمط: '+e.message,'error');}
}

// ======================== MARKDOWN EDITOR ========================
function renderMarkdown(){
  const md=document.getElementById('md-input').value;
  let html=md
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/^### (.+)$/gm,'<h3 style="color:#a78bfa;margin:.6em 0">$1</h3>')
    .replace(/^## (.+)$/gm,'<h2 style="color:#c4b5fd;margin:.7em 0;border-bottom:1px solid var(--border);padding-bottom:5px">$1</h2>')
    .replace(/^# (.+)$/gm,'<h1 style="color:#ddd6fe;margin:.8em 0;border-bottom:2px solid var(--accent);padding-bottom:6px">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g,'<strong style="color:#fff">$1</strong>')
    .replace(/\*(.+?)\*/g,'<em style="color:#c4b5fd">$1</em>')
    .replace(/`(.+?)`/g,'<code style="background:rgba(124,58,237,.2);padding:1px 6px;border-radius:4px;color:#a78bfa;font-family:monospace">$1</code>')
    .replace(/^\-\- (.+)$/gm,'<li style="margin:.3em 0;color:var(--text)">$1</li>')
    .replace(/^- (.+)$/gm,'<li style="margin:.3em 0;color:var(--text)">$1</li>')
    .replace(/^\> (.+)$/gm,'<blockquote style="border-left:3px solid var(--accent);padding-left:12px;color:var(--muted);margin:.5em 0">$1</blockquote>')
    .replace(/\[(.+?)\]\((.+?)\)/g,'<a href="$2" target="_blank" style="color:#60a5fa;text-decoration:underline">$1</a>')
    .replace(/^---$/gm,'<hr style="border:none;border-top:1px solid var(--border);margin:.8em 0">')
    .replace(/\n/g,'<br>');
  document.getElementById('md-preview').innerHTML=html||'<span style="color:var(--muted);font-style:italic">ستظهر المعاينة هنا...</span>';
}
function mdInsert(pre,post){
  const ta=document.getElementById('md-input');
  const s=ta.selectionStart,e=ta.selectionEnd;
  const sel=ta.value.substring(s,e);
  ta.value=ta.value.substring(0,s)+pre+sel+post+ta.value.substring(e);
  ta.focus();ta.selectionStart=s+pre.length;ta.selectionEnd=s+pre.length+sel.length;
  renderMarkdown();
}

// ======================== HELPERS ========================
async function postJson(url,data){
  try{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return await r.json();}
  catch(e){return{error:'Connection error: '+e.message};}
}
function showMsg(id,msg,type){const e=document.getElementById(id);if(!e)return;e.textContent=msg;e.className='status-msg show status-'+type;}
function clearMsg(id){const e=document.getElementById(id);if(e)e.className='status-msg';}
function showEl(id){const e=document.getElementById(id);if(e)e.classList.add('show');}
function hideEl(id){const e=document.getElementById(id);if(e)e.classList.remove('show');}
function esc(s){return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'");}

// ======================== KEYBOARD ========================
document.addEventListener('keydown', e => {
  const active = document.querySelector('.section.active')?.id;
  if(e.key==='Enter'){
    if(active==='sec-analyze'&&document.activeElement.id==='analyze-url') analyzeLink();
    if(active==='sec-network'&&document.activeElement.id==='ip-input') lookupIP();
    if(active==='sec-network'&&document.activeElement.id==='ping-input') doPing();
    if(active==='sec-home'&&document.activeElement.id==='quick-url') quickAction();
    if(active==='sec-video'&&document.activeElement.id==='vid-url') fetchVideoInfo();
  }
  if(e.key==='Escape') closeSidebar();
});

// ======================== INIT ========================
document.addEventListener('DOMContentLoaded', () => {
  initFontSize();
  initAccent();
  applyLang(currentLang);
  buildPlatforms();
  loadDisk();
  initWorldClock();
  populateCurrencySelects();
  setUnitCat('length');
  renderShortHistory();
  loadQuote();
  if(Notification&&Notification.permission==='default') Notification.requestPermission();
});
</script>
</body>
</html>
'''


DOWNLOADS_DIR = os.environ.get("APP_DOWNLOADS_DIR") or os.path.join(os.path.expanduser("~"), "downloads")
VIDEOS_DIR    = os.path.join(DOWNLOADS_DIR, "videos")
FILES_DIR     = os.path.join(DOWNLOADS_DIR, "files")
TEMP_DIR      = os.path.join(DOWNLOADS_DIR, ".temp")
SETTINGS_FILE = os.path.join(DOWNLOADS_DIR, "settings.json")
NOTES_FILE    = os.path.join(DOWNLOADS_DIR, "notes.json")

for d in [VIDEOS_DIR, FILES_DIR, TEMP_DIR]:
    os.makedirs(d, exist_ok=True)

DEFAULT_SETTINGS = {
    'access_code': '125678',
    'accent_color': '#7c3aed',
    'max_concurrent': 3,
    'auto_detect': True,
    'notify_on_complete': True,
    'theme': 'dark',
    'default_quality': '720p',
    'save_history': True,
    'show_thumbnails': True,
}

def load_settings():
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE) as f:
                s = json.load(f)
                return {**DEFAULT_SETTINGS, **s}
    except:
        pass
    return dict(DEFAULT_SETTINGS)

def save_settings(s):
    with open(SETTINGS_FILE, 'w') as f:
        json.dump(s, f, ensure_ascii=False, indent=2)

def load_notes():
    try:
        if os.path.exists(NOTES_FILE):
            with open(NOTES_FILE) as f:
                return json.load(f)
    except:
        pass
    return []

def save_notes(notes):
    with open(NOTES_FILE, 'w') as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)

app_settings = load_settings()

SUPPORTED_PLATFORMS = {
    'يوتيوب': ['youtube.com', 'youtu.be', 'm.youtube.com'],
    'تيك توك': ['tiktok.com', 'vm.tiktok.com'],
    'انستغرام': ['instagram.com', 'instagr.am'],
    'فيسبوك': ['facebook.com', 'fb.watch', 'fb.com'],
    'تويتر / X': ['twitter.com', 'x.com'],
    'ريديت': ['reddit.com', 'redd.it'],
    'تويتش': ['twitch.tv', 'clips.twitch.tv'],
    'فيميو': ['vimeo.com'],
    'دايلي موشن': ['dailymotion.com', 'dai.ly'],
    'VK': ['vk.com'],
    'OK.ru': ['ok.ru'],
    'بيليبيلي': ['bilibili.com'],
    'لينكد إن': ['linkedin.com'],
    'سناب شات': ['snapchat.com'],
    'ساوند كلاود': ['soundcloud.com'],
    'ميكسكلاود': ['mixcloud.com'],
    'بوديان': ['podbean.com'],
    'تمبلر': ['tumblr.com'],
    'ديلي موشن': ['dailymotion.com'],
}

QUALITY_PRESETS = {
    '4K': 'best[height<=2160]/bestvideo[height<=2160]+bestaudio/best[height<=2160]',
    '1080p': 'best[height<=1080]/bestvideo[height<=1080]+bestaudio/best[height<=1080]',
    '720p': 'best[height<=720]/bestvideo[height<=720]+bestaudio/best[height<=720]',
    '480p': 'best[height<=480]/bestvideo[height<=480]+bestaudio/best',
    '360p': 'best[height<=360]/worst',
    'صوت فقط (MP3)': 'bestaudio/best',
}

HAS_FFMPEG = shutil.which('ffmpeg') is not None

def _h(q):
    m = re.match(r'(\d+)p', q)
    return int(m.group(1)) if m else (2160 if q == '4K' else 720)

def pick_format(quality):
    """Without ffmpeg (Android) only single-file formats can be used (no merge)."""
    if HAS_FFMPEG:
        return QUALITY_PRESETS.get(quality, QUALITY_PRESETS['720p'])
    if quality == 'صوت فقط (MP3)':
        return 'bestaudio[ext=m4a]/bestaudio/best'
    h = _h(quality)
    return (f'best[ext=mp4][height<={h}][vcodec!=none][acodec!=none]/'
            f'best[height<={h}][vcodec!=none][acodec!=none]/'
            f'best[ext=mp4]/best')

ANSI_RE = re.compile(r'\x1b\[[0-9;]*[mGKHF]')

stats = {
    'total_downloads': 0,
    'total_analyses': 0,
    'video_downloads': 0,
    'file_downloads': 0,
    'errors': 0,
    'sessions': 0,
    'size_downloaded': 0,
    'history': [],
    'start_time': datetime.now().isoformat(),
}

active_downloads = {}
download_queue = []


def strip_ansi(text):
    return ANSI_RE.sub('', str(text))

def detect_platform(url):
    url_lower = url.lower()
    for platform, domains in SUPPORTED_PLATFORMS.items():
        for domain in domains:
            if domain in url_lower:
                return platform
    return None

def is_valid_url(text):
    try:
        r = urlparse(text)
        return r.scheme in ('http', 'https') and '.' in r.netloc
    except:
        return False

def format_size(b):
    if not b:
        return "0 B"
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if b < 1024:
            return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} TB"

def format_duration(secs):
    if not secs:
        return "غير معروف"
    m, s = divmod(int(secs), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"

def require_login(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return jsonify({'error': 'غير مصرح'}), 401
        return f(*args, **kwargs)
    return decorated

# ======================== AUTH ========================
@app.route('/')
def index():
    if session.get('logged_in'):
        return redirect(url_for('dashboard'))
    return render_template_string(INDEX_HTML)

@app.route('/login', methods=['POST'])
def login():
    code = request.form.get('code', '').strip()
    current_settings = load_settings()
    if code == current_settings.get('access_code', '125678'):
        session['logged_in'] = True
        session.permanent = True
        stats['sessions'] += 1
        return redirect(url_for('dashboard'))
    return render_template_string(INDEX_HTML, error='رمز الدخول غير صحيح! حاول مجدداً.')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('index'))
    return render_template_string(DASHBOARD_HTML)

# ======================== VIDEO ========================
@app.route('/api/video-info', methods=['POST'])
@require_login
def video_info():
    url = request.json.get('url', '').strip()
    if not is_valid_url(url):
        return jsonify({'error': 'الرابط غير صالح'})
    try:
        ydl_opts = {'quiet': True, 'no_warnings': True, 'socket_timeout': 20}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
        stats['total_analyses'] += 1
        return jsonify({
            'success': True,
            'title': info.get('title', 'بدون عنوان'),
            'uploader': info.get('uploader', 'غير معروف'),
            'duration': format_duration(info.get('duration')),
            'platform': detect_platform(url) or 'غير معروف',
            'thumbnail': info.get('thumbnail', ''),
            'description': (info.get('description') or '')[:400],
            'view_count': f"{info.get('view_count', 0):,}" if info.get('view_count') else 'غير معروف',
            'like_count': f"{info.get('like_count', 0):,}" if info.get('like_count') else 'غير معروف',
            'upload_date': info.get('upload_date', ''),
            'qualities': list(QUALITY_PRESETS.keys()),
        })
    except Exception as e:
        stats['errors'] += 1
        return jsonify({'error': f'فشل جلب المعلومات: {strip_ansi(str(e))[:300]}'})

@app.route('/api/download-video', methods=['POST'])
@require_login
def download_video():
    data = request.json
    url = data.get('url', '').strip()
    quality = data.get('quality', app_settings.get('default_quality', '720p'))
    if not is_valid_url(url):
        return jsonify({'error': 'الرابط غير صالح'})

    dl_id = hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()[:8]
    active_downloads[dl_id] = {'status': 'في الانتظار...', 'progress': 0, 'url': url, 'type': 'video'}

    def do_download():
        try:
            fmt = pick_format(quality)
            safe_time = datetime.now().strftime('%Y%m%d_%H%M%S')
            out_tmpl = os.path.join(VIDEOS_DIR, f'{safe_time}_%(title).60s.%(ext)s')
            ydl_opts = {
                'format': fmt,
                'outtmpl': out_tmpl,
                'quiet': True,
                'no_warnings': True,
                'noplaylist': True,
            }
            if HAS_FFMPEG:
                if quality == 'صوت فقط (MP3)':
                    ydl_opts['postprocessors'] = [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3'}]
                else:
                    ydl_opts['postprocessors'] = [
                        {'key': 'FFmpegVideoConvertor', 'preferedformat': 'mp4'}
                    ]
                    ydl_opts['merge_output_format'] = 'mp4'

            def progress_hook(d):
                if d['status'] == 'downloading':
                    raw = strip_ansi(d.get('_percent_str', '0%')).strip().replace('%', '')
                    try:
                        pct = float(raw)
                        spd = strip_ansi(d.get('_speed_str', '')).strip()
                        eta = strip_ansi(d.get('_eta_str', '')).strip()
                        active_downloads[dl_id]['progress'] = pct
                        active_downloads[dl_id]['status'] = f"تحميل {pct:.1f}%"
                        active_downloads[dl_id]['speed'] = spd
                        active_downloads[dl_id]['eta'] = eta
                    except:
                        pass
                elif d['status'] == 'finished':
                    active_downloads[dl_id]['progress'] = 99
                    active_downloads[dl_id]['status'] = 'جاري المعالجة...'

            ydl_opts['progress_hooks'] = [progress_hook]
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)

            files = sorted(Path(VIDEOS_DIR).glob('*'), key=lambda f: f.stat().st_mtime, reverse=True)
            if files:
                fpath = str(files[0])
                fsize = os.path.getsize(fpath)
                fname = os.path.basename(fpath)
                stats['total_downloads'] += 1
                stats['video_downloads'] += 1
                stats['size_downloaded'] += fsize
                _add_history('فيديو', fname, fsize, quality, detect_platform(url) or 'غير معروف')
                active_downloads[dl_id].update({
                    'status': 'تم التحميل ✅',
                    'progress': 100,
                    'filename': fname,
                    'size': format_size(fsize),
                    'done': True,
                })
            else:
                active_downloads[dl_id].update({'status': 'لم يُعثر على الملف', 'error': True})
        except Exception as e:
            active_downloads[dl_id].update({'status': f'خطأ: {strip_ansi(str(e))[:200]}', 'error': True})
            stats['errors'] += 1

    threading.Thread(target=do_download, daemon=True).start()
    return jsonify({'success': True, 'dl_id': dl_id})

@app.route('/api/download-progress/<dl_id>')
@require_login
def download_progress(dl_id):
    return jsonify(active_downloads.get(dl_id, {'status': 'غير موجود', 'progress': 0}))

@app.route('/api/active-downloads')
@require_login
def get_active_downloads():
    return jsonify({'downloads': [
        {'id': k, **v} for k, v in active_downloads.items()
        if not v.get('done') and not v.get('error')
    ]})

# ======================== FILE DOWNLOAD ========================
@app.route('/api/download-file', methods=['POST'])
@require_login
def download_file_route():
    url = request.json.get('url', '').strip()
    custom_name = request.json.get('name', '').strip()
    if not is_valid_url(url):
        return jsonify({'error': 'الرابط غير صالح'})

    dl_id = hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()[:8]
    active_downloads[dl_id] = {'status': 'جاري التحميل...', 'progress': 0, 'type': 'file'}

    def do_file_download():
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            resp = requests.get(url, stream=True, headers=headers, timeout=30, allow_redirects=True)
            resp.raise_for_status()
            parsed = urlparse(resp.url)
            if custom_name:
                fname = re.sub(r'[<>:"/\\|?*]', '_', custom_name)
            else:
                fname = unquote(os.path.basename(parsed.path)) or 'downloaded_file'
                fname = re.sub(r'[<>:"/\\|?*]', '_', fname)
            if not fname or fname in ['_', '']:
                fname = f"file_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            fpath = os.path.join(FILES_DIR, fname)
            total = int(resp.headers.get('content-length', 0))
            downloaded = 0
            with open(fpath, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total:
                            pct = (downloaded / total) * 100
                            active_downloads[dl_id]['progress'] = pct
                            active_downloads[dl_id]['status'] = f"تحميل {pct:.1f}%"
                            active_downloads[dl_id]['downloaded'] = format_size(downloaded)
                            active_downloads[dl_id]['total'] = format_size(total)
            fsize = os.path.getsize(fpath)
            stats['total_downloads'] += 1
            stats['file_downloads'] += 1
            stats['size_downloaded'] += fsize
            _add_history('ملف', fname, fsize, '-', parsed.netloc)
            active_downloads[dl_id].update({'status': 'تم التحميل ✅', 'progress': 100,
                                             'filename': fname, 'size': format_size(fsize), 'done': True})
        except Exception as e:
            active_downloads[dl_id].update({'status': f'خطأ: {strip_ansi(str(e))[:200]}', 'error': True})
            stats['errors'] += 1

    threading.Thread(target=do_file_download, daemon=True).start()
    return jsonify({'success': True, 'dl_id': dl_id})

def _add_history(ftype, fname, fsize, quality, platform):
    if not app_settings.get('save_history', True):
        return
    stats['history'].insert(0, {
        'type': ftype, 'name': fname, 'size': format_size(fsize),
        'time': datetime.now().strftime('%H:%M %Y-%m-%d'),
        'quality': quality, 'platform': platform,
    })
    if len(stats['history']) > 100:
        stats['history'] = stats['history'][:100]

# ======================== LINK ANALYSIS ========================
@app.route('/api/analyze-link', methods=['POST'])
@require_login
def analyze_link():
    url = request.json.get('url', '').strip()
    if not is_valid_url(url):
        return jsonify({'error': 'الرابط غير صالح'})
    try:
        parsed = urlparse(url)
        result = {
            'url': url, 'domain': parsed.netloc,
            'scheme': parsed.scheme, 'path': parsed.path or '/',
            'secure': parsed.scheme == 'https',
            'platform': detect_platform(url) or 'غير معروف',
            'query': parsed.query or 'لا يوجد',
            'fragment': parsed.fragment or 'لا يوجد',
        }
        try:
            result['ip'] = socket.gethostbyname(parsed.netloc.split(':')[0])
        except:
            result['ip'] = 'غير معروف'
        try:
            headers_req = {'User-Agent': 'Mozilla/5.0'}
            resp = requests.head(url, timeout=8, allow_redirects=True, headers=headers_req)
            result.update({
                'status_code': resp.status_code,
                'final_url': resp.url,
                'redirects': len(resp.history),
                'content_type': resp.headers.get('content-type', 'غير معروف'),
                'content_length': format_size(int(resp.headers['content-length'])) if resp.headers.get('content-length') else 'غير معروف',
                'server': resp.headers.get('server', 'غير معروف'),
                'x_powered_by': resp.headers.get('x-powered-by', 'غير معروف'),
                'cache_control': resp.headers.get('cache-control', 'غير معروف'),
                'last_modified': resp.headers.get('last-modified', 'غير معروف'),
            })
        except Exception as e:
            result.update({'status_code': f'خطأ: {str(e)[:60]}', 'final_url': url, 'redirects': 0})
        stats['total_analyses'] += 1
        return jsonify({'success': True, 'result': result})
    except Exception as e:
        return jsonify({'error': str(e)[:200]})

# ======================== FILES ========================
@app.route('/api/files')
@require_login
def list_files():
    search = request.args.get('q', '').lower()
    sort_by = request.args.get('sort', 'date')
    files = []
    for folder, ftype in [(VIDEOS_DIR, 'فيديو'), (FILES_DIR, 'ملف')]:
        for f in Path(folder).glob('*'):
            if f.is_file() and not f.name.startswith('.'):
                if search and search not in f.name.lower():
                    continue
                files.append({
                    'name': f.name, 'size': format_size(f.stat().st_size),
                    'size_bytes': f.stat().st_size,
                    'type': ftype, 'path': str(f),
                    'date': datetime.fromtimestamp(f.stat().st_mtime).strftime('%Y-%m-%d %H:%M'),
                    'ts': f.stat().st_mtime,
                    'ext': f.suffix.lower(),
                })
    if sort_by == 'size':
        files.sort(key=lambda x: x['size_bytes'], reverse=True)
    elif sort_by == 'name':
        files.sort(key=lambda x: x['name'].lower())
    else:
        files.sort(key=lambda x: x['ts'], reverse=True)
    return jsonify({'files': files[:200], 'total': len(files)})

@app.route('/api/download-local/<path:filename>')
def download_local(filename):
    if not session.get('logged_in'):
        return redirect(url_for('index'))
    for folder in [VIDEOS_DIR, FILES_DIR]:
        fpath = os.path.join(folder, filename)
        if os.path.exists(fpath):
            return send_file(fpath, as_attachment=True)
    return "الملف غير موجود", 404

@app.route('/api/delete-file', methods=['POST'])
@require_login
def delete_file():
    fname = request.json.get('filename', '')
    for folder in [VIDEOS_DIR, FILES_DIR]:
        fpath = os.path.join(folder, fname)
        if os.path.exists(fpath):
            os.remove(fpath)
            return jsonify({'success': True})
    return jsonify({'error': 'الملف غير موجود'})

@app.route('/api/bulk-delete', methods=['POST'])
@require_login
def bulk_delete():
    filenames = request.json.get('files', [])
    deleted, failed = 0, 0
    for fname in filenames:
        found = False
        for folder in [VIDEOS_DIR, FILES_DIR]:
            fpath = os.path.join(folder, fname)
            if os.path.exists(fpath):
                os.remove(fpath)
                deleted += 1
                found = True
                break
        if not found:
            failed += 1
    return jsonify({'success': True, 'deleted': deleted, 'failed': failed})

@app.route('/api/rename-file', methods=['POST'])
@require_login
def rename_file():
    old = request.json.get('old_name', '')
    new = request.json.get('new_name', '')
    new = re.sub(r'[<>:"/\\|?*]', '_', new)
    for folder in [VIDEOS_DIR, FILES_DIR]:
        old_path = os.path.join(folder, old)
        if os.path.exists(old_path):
            new_path = os.path.join(folder, new)
            os.rename(old_path, new_path)
            return jsonify({'success': True})
    return jsonify({'error': 'الملف غير موجود'})

@app.route('/api/disk-space')
@require_login
def disk_space():
    stat = shutil.disk_usage(DOWNLOADS_DIR)
    videos = sum(f.stat().st_size for f in Path(VIDEOS_DIR).glob('*') if f.is_file())
    files = sum(f.stat().st_size for f in Path(FILES_DIR).glob('*') if f.is_file())
    return jsonify({
        'total': format_size(stat.total),
        'used': format_size(stat.used),
        'free': format_size(stat.free),
        'free_pct': round((stat.free / stat.total) * 100, 1),
        'videos_size': format_size(videos),
        'files_size': format_size(files),
        'app_size': format_size(videos + files),
    })

# ======================== STATS ========================
@app.route('/api/stats')
@require_login
def get_stats():
    uptime_secs = int((datetime.now() - datetime.fromisoformat(stats['start_time'])).total_seconds())
    h, r = divmod(uptime_secs, 3600)
    m, s = divmod(r, 60)
    return jsonify({
        **{k: v for k, v in stats.items() if k != 'history'},
        'size_downloaded': format_size(stats['size_downloaded']),
        'history': stats['history'][:30],
        'uptime': f"{h}:{m:02d}:{s:02d}",
        'success_rate': round(stats['total_downloads'] / max(1, stats['total_downloads'] + stats['errors']) * 100, 1),
    })

# ======================== QR CODE ========================
@app.route('/api/qr-generate', methods=['POST'])
@require_login
def qr_generate():
    data = request.json.get('text', '').strip()
    color = request.json.get('color', '#000000')
    bg_color = request.json.get('bg_color', '#ffffff')
    size = max(4, min(20, int(request.json.get('size', 10))))
    if not data:
        return jsonify({'error': 'أدخل النص أو الرابط'})
    try:
        qr = qrcode.QRCode(version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=size, border=4)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color=color, back_color=bg_color)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode()
        return jsonify({'success': True, 'image': f'data:image/png;base64,{b64}'})
    except Exception as e:
        return jsonify({'error': f'فشل إنشاء الباركود: {str(e)[:100]}'})

@app.route('/api/qr-read', methods=['POST'])
@require_login
def qr_read():
    if 'file' not in request.files:
        return jsonify({'error': 'لم يتم رفع صورة'})
    f = request.files['file']
    try:
        img = Image.open(io.BytesIO(f.read())).convert('RGB')
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode()
        return jsonify({'success': True, 'preview': f'data:image/png;base64,{b64}', 'needs_js_decode': True})
    except Exception as e:
        return jsonify({'error': f'خطأ: {str(e)[:100]}'})

# ======================== TOOLS ========================
@app.route('/api/hash-text', methods=['POST'])
@require_login
def hash_text():
    text = request.json.get('text', '')
    encoding = request.json.get('encoding', 'utf-8')
    try:
        encoded = text.encode(encoding, errors='replace')
        return jsonify({'success': True, 'results': {
            'MD5': hashlib.md5(encoded).hexdigest(),
            'SHA1': hashlib.sha1(encoded).hexdigest(),
            'SHA256': hashlib.sha256(encoded).hexdigest(),
            'SHA512': hashlib.sha512(encoded).hexdigest(),
            'SHA3-256': hashlib.sha3_256(encoded).hexdigest(),
        }})
    except Exception as e:
        return jsonify({'error': str(e)[:100]})

@app.route('/api/encode-decode', methods=['POST'])
@require_login
def encode_decode():
    text = request.json.get('text', '')
    mode = request.json.get('mode', 'b64_encode')
    try:
        if mode == 'b64_encode':
            result = base64.b64encode(text.encode()).decode()
        elif mode == 'b64_decode':
            result = base64.b64decode(text.encode()).decode(errors='replace')
        elif mode == 'url_encode':
            result = quote(text)
        elif mode == 'url_decode':
            result = unquote_plus(text)
        elif mode == 'hex_encode':
            result = text.encode().hex()
        elif mode == 'hex_decode':
            result = bytes.fromhex(text).decode(errors='replace')
        elif mode == 'reverse':
            result = text[::-1]
        elif mode == 'upper':
            result = text.upper()
        elif mode == 'lower':
            result = text.lower()
        elif mode == 'count':
            words = len(text.split())
            chars = len(text)
            lines = text.count('\n') + 1
            result = f"أحرف: {chars} | كلمات: {words} | أسطر: {lines}"
        elif mode == 'binary':
            result = ' '.join(format(ord(c), '08b') for c in text[:200])
        else:
            result = text
        return jsonify({'success': True, 'result': result})
    except Exception as e:
        return jsonify({'error': f'خطأ: {str(e)[:100]}'})

@app.route('/api/ip-lookup', methods=['POST'])
@require_login
def ip_lookup():
    target = request.json.get('target', '').strip()
    try:
        if not target:
            return jsonify({'error': 'أدخل عنوان IP أو اسم نطاق'})
        # Resolve hostname to IP
        try:
            ip = socket.gethostbyname(target)
        except:
            ip = target
        try:
            resp = requests.get(f'http://ip-api.com/json/{ip}?lang=ar', timeout=8)
            data = resp.json()
            if data.get('status') == 'success':
                lat = data.get('lat', '')
                lon = data.get('lon', '')
                maps_url = f'https://www.google.com/maps?q={lat},{lon}' if lat and lon else ''
                return jsonify({'success': True, 'ip': ip, 'maps_url': maps_url, 'lat': lat, 'lon': lon, 'data': {
                    'البلد': data.get('country', 'غير معروف'),
                    'المدينة': data.get('city', 'غير معروف'),
                    'المنطقة': data.get('regionName', 'غير معروف'),
                    'مزود الخدمة': data.get('isp', 'غير معروف'),
                    'المنظمة': data.get('org', 'غير معروف'),
                    'المنطقة الزمنية': data.get('timezone', 'غير معروف'),
                    'خط العرض': str(lat),
                    'خط الطول': str(lon),
                    'رمز البلد': data.get('countryCode', ''),
                }})
        except:
            pass
        # fallback
        try:
            hostname = socket.gethostbyaddr(ip)[0]
        except:
            hostname = 'غير معروف'
        return jsonify({'success': True, 'ip': ip, 'data': {'اسم المضيف': hostname}})
    except Exception as e:
        return jsonify({'error': str(e)[:200]})

@app.route('/api/ping', methods=['POST'])
@require_login
def ping_host():
    host = request.json.get('host', '').strip()
    if not host:
        return jsonify({'error': 'أدخل اسم المضيف'})
    try:
        clean = urlparse(host).netloc or host
        clean = re.sub(r'[^a-zA-Z0-9.\-]', '', clean)
        results = []
        for i in range(4):
            t0 = time.time()
            try:
                ip = socket.gethostbyname(clean)
                sock = socket.create_connection((ip, 80), timeout=3)
                sock.close()
                ms = round((time.time() - t0) * 1000, 1)
                results.append({'seq': i+1, 'ms': ms, 'status': 'ok', 'ip': ip})
            except Exception as e:
                results.append({'seq': i+1, 'ms': None, 'status': 'timeout', 'ip': ''})
            time.sleep(0.2)
        successful = [r for r in results if r['status'] == 'ok']
        return jsonify({'success': True, 'host': clean, 'results': results,
            'avg_ms': round(sum(r['ms'] for r in successful) / len(successful), 1) if successful else None,
            'packet_loss': round((len(results) - len(successful)) / len(results) * 100)})
    except Exception as e:
        return jsonify({'error': str(e)[:150]})

@app.route('/api/image-process', methods=['POST'])
@require_login
def image_process():
    if 'file' not in request.files:
        return jsonify({'error': 'لم يتم رفع صورة'})
    f = request.files['file']
    op = request.form.get('op', 'info')
    try:
        img = Image.open(io.BytesIO(f.read()))
        original_format = img.format or 'PNG'

        if op == 'info':
            return jsonify({'success': True, 'info': {
                'العرض': f"{img.width} بكسل",
                'الارتفاع': f"{img.height} بكسل",
                'الصيغة': original_format,
                'النمط': img.mode,
                'الحجم': format_size(f.tell() if hasattr(f, 'tell') else 0),
            }})
        elif op == 'grayscale':
            img = ImageOps.grayscale(img)
        elif op == 'blur':
            img = img.filter(ImageFilter.BLUR)
        elif op == 'sharpen':
            img = img.filter(ImageFilter.SHARPEN)
        elif op == 'flip_h':
            img = ImageOps.mirror(img)
        elif op == 'flip_v':
            img = ImageOps.flip(img)
        elif op == 'rotate':
            angle = int(request.form.get('angle', 90))
            img = img.rotate(angle, expand=True)
        elif op == 'resize':
            w = int(request.form.get('width', img.width))
            h = int(request.form.get('height', img.height))
            img = img.resize((w, h), Image.LANCZOS)
        elif op == 'invert':
            img = img.convert('RGB')
            img = ImageOps.invert(img)
        elif op == 'brightness':
            factor = float(request.form.get('factor', 1.5))
            img = ImageEnhance.Brightness(img).enhance(factor)
        elif op == 'contrast':
            factor = float(request.form.get('factor', 1.5))
            img = ImageEnhance.Contrast(img).enhance(factor)
        elif op == 'thumbnail':
            img.thumbnail((300, 300))

        if img.mode in ('RGBA', 'P') and op not in ('grayscale',):
            img = img.convert('RGBA')
            out_format = 'PNG'
        else:
            out_format = 'JPEG' if img.mode == 'RGB' else 'PNG'

        buf = io.BytesIO()
        img.save(buf, format=out_format)
        buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode()
        mime = 'image/png' if out_format == 'PNG' else 'image/jpeg'
        return jsonify({'success': True, 'image': f'data:{mime};base64,{b64}',
                        'width': img.width, 'height': img.height})
    except Exception as e:
        return jsonify({'error': f'خطأ: {str(e)[:150]}'})

# ======================== NOTES / BOOKMARKS ========================
@app.route('/api/notes', methods=['GET'])
@require_login
def get_notes():
    return jsonify({'notes': load_notes()})

@app.route('/api/notes', methods=['POST'])
@require_login
def add_note():
    title = request.json.get('title', '').strip()
    content = request.json.get('content', '').strip()
    color = request.json.get('color', '#7c3aed')
    if not content:
        return jsonify({'error': 'المحتوى فارغ'})
    notes = load_notes()
    note = {'id': int(time.time()*1000), 'title': title, 'content': content,
            'color': color, 'created': datetime.now().strftime('%Y-%m-%d %H:%M')}
    notes.insert(0, note)
    save_notes(notes)
    return jsonify({'success': True, 'note': note})

@app.route('/api/notes/<int:note_id>', methods=['DELETE'])
@require_login
def delete_note(note_id):
    notes = [n for n in load_notes() if n.get('id') != note_id]
    save_notes(notes)
    return jsonify({'success': True})

# ======================== SETTINGS ========================
@app.route('/api/settings', methods=['GET'])
@require_login
def get_settings():
    s = load_settings()
    s.pop('access_code', None)
    return jsonify({'settings': s})

@app.route('/api/settings', methods=['POST'])
@require_login
def update_settings():
    global app_settings
    current = load_settings()
    data = request.json

    # Handle access code change
    if data.get('new_code'):
        if data.get('current_code') != current.get('access_code'):
            return jsonify({'error': 'رمز الدخول الحالي غير صحيح'})
        current['access_code'] = data['new_code']

    # Update other settings
    for key in ['accent_color', 'max_concurrent', 'auto_detect', 'notify_on_complete',
                'theme', 'default_quality', 'save_history', 'show_thumbnails']:
        if key in data:
            current[key] = data[key]

    save_settings(current)
    app_settings = current
    return jsonify({'success': True, 'message': 'تم حفظ الإعدادات'})

@app.route('/api/settings/reset', methods=['POST'])
@require_login
def reset_settings():
    global app_settings
    save_settings(DEFAULT_SETTINGS)
    app_settings = dict(DEFAULT_SETTINGS)
    return jsonify({'success': True})

@app.route('/api/clear-history', methods=['POST'])
@require_login
def clear_history():
    stats['history'] = []
    return jsonify({'success': True})

@app.route('/api/app-info')
@require_login
def app_info():
    s = load_settings()
    return jsonify({
        'accent_color': s.get('accent_color', '#7c3aed'),
        'theme': s.get('theme', 'dark'),
        'default_quality': s.get('default_quality', '720p'),
        'notify_on_complete': s.get('notify_on_complete', True),
        'auto_detect': s.get('auto_detect', True),
        'show_thumbnails': s.get('show_thumbnails', True),
        'platforms_count': len(SUPPORTED_PLATFORMS),
    })

# ======================== WEATHER ========================
@app.route('/api/weather', methods=['POST'])
@require_login
def get_weather():
    city = request.json.get('city', '').strip()
    if not city:
        return jsonify({'error': 'أدخل اسم المدينة'})
    try:
        resp = requests.get(
            f'https://wttr.in/{urllib.parse.quote(city)}?format=j1',
            timeout=10, headers={'User-Agent': 'SmartDownloader/1.0'}
        )
        data = resp.json()
        cur = data['current_condition'][0]
        area = data['nearest_area'][0]
        country = area['country'][0]['value']
        area_name = area['areaName'][0]['value']
        weather_desc = cur['weatherDesc'][0]['value']
        
        # Map weather codes to emojis
        wcode = int(cur.get('weatherCode', 113))
        def weather_emoji(code):
            if code == 113: return '☀️'
            if code in [116,119]: return '⛅'
            if code in [122,143,248,260]: return '🌫️'
            if code in [176,263,266,293,296]: return '🌦️'
            if code in [299,302,305,308]: return '🌧️'
            if code in [317,320,323,326,329,332,335,338]: return '❄️'
            if code in [200,386,389,392,395]: return '⛈️'
            return '🌤️'

        forecast = []
        for day in data.get('weather', [])[:3]:
            forecast.append({
                'date': day['date'],
                'max_c': day['maxtempC'],
                'min_c': day['mintempC'],
                'desc': day['hourly'][4]['weatherDesc'][0]['value'],
                'emoji': weather_emoji(int(day['hourly'][4].get('weatherCode', 113))),
            })

        return jsonify({'success': True, 'data': {
            'city': f"{area_name}, {country}",
            'temp_c': cur['temp_C'],
            'temp_f': cur['temp_F'],
            'feels_c': cur['FeelsLikeC'],
            'humidity': cur['humidity'],
            'wind_kmph': cur['windspeedKmph'],
            'wind_dir': cur['winddir16Point'],
            'visibility': cur['visibility'],
            'pressure': cur['pressure'],
            'uv': cur['uvIndex'],
            'desc': weather_desc,
            'emoji': weather_emoji(wcode),
            'forecast': forecast,
        }})
    except Exception as e:
        return jsonify({'error': f'فشل جلب الطقس: {str(e)[:150]}'})


# ======================== CURRENCY ========================
@app.route('/api/currency', methods=['POST'])
@require_login
def convert_currency():
    amount = float(request.json.get('amount', 1) or 1)
    from_c = request.json.get('from', 'USD').upper()
    to_c   = request.json.get('to', 'SAR').upper()
    try:
        resp = requests.get(
            f'https://api.frankfurter.app/latest?from={from_c}&to={to_c}',
            timeout=8
        )
        data = resp.json()
        if 'rates' not in data:
            return jsonify({'error': 'عملة غير مدعومة'})
        rate = data['rates'].get(to_c)
        if not rate:
            return jsonify({'error': f'لا يوجد سعر صرف لـ {to_c}'})
        result = round(amount * rate, 4)
        return jsonify({'success': True, 'rate': rate, 'result': result,
                        'from': from_c, 'to': to_c, 'amount': amount,
                        'date': data.get('date', '')})
    except Exception as e:
        return jsonify({'error': str(e)[:150]})

@app.route('/api/currency-rates', methods=['POST'])
@require_login
def get_rates():
    base = request.json.get('base', 'USD').upper()
    try:
        resp = requests.get(f'https://api.frankfurter.app/latest?from={base}', timeout=8)
        data = resp.json()
        common = ['SAR','AED','USD','EUR','GBP','JPY','CNY','INR','EGP','TRY','KWD','QAR','BHD','OMR','JOD','MAD','DZD','TND','LYD','MYR','NGN','ZAR']
        rates = {k: v for k, v in data.get('rates', {}).items() if k in common}
        return jsonify({'success': True, 'base': base, 'rates': rates, 'date': data.get('date','')})
    except Exception as e:
        return jsonify({'error': str(e)[:100]})


# ======================== URL SHORTENER ========================
@app.route('/api/shorten-url', methods=['POST'])
@require_login
def shorten_url():
    url = request.json.get('url', '').strip()
    if not is_valid_url(url):
        return jsonify({'error': 'الرابط غير صالح'})
    # Try is.gd first
    try:
        r = requests.get(f'https://is.gd/create.php?format=simple&url={urllib.parse.quote(url)}', timeout=8)
        if r.status_code == 200 and r.text.startswith('http'):
            return jsonify({'success': True, 'short': r.text.strip(), 'service': 'is.gd'})
    except:
        pass
    # Fallback: tinyurl
    try:
        r = requests.get(f'https://tinyurl.com/api-create.php?url={urllib.parse.quote(url)}', timeout=8)
        if r.status_code == 200 and r.text.startswith('http'):
            return jsonify({'success': True, 'short': r.text.strip(), 'service': 'TinyURL'})
    except:
        pass
    return jsonify({'error': 'فشل اختصار الرابط'})


# ======================== BATCH DOWNLOAD ========================
@app.route('/api/batch-analyze', methods=['POST'])
@require_login
def batch_analyze():
    urls = request.json.get('urls', [])
    urls = [u.strip() for u in urls if u.strip() and is_valid_url(u.strip())][:10]
    results = []
    for url in urls:
        platform = detect_platform(url)
        parsed = urlparse(url)
        try:
            resp = requests.head(url, timeout=5, allow_redirects=True,
                                 headers={'User-Agent':'Mozilla/5.0'})
            ct = resp.headers.get('content-type','')
            size = resp.headers.get('content-length','')
            results.append({
                'url': url, 'domain': parsed.netloc,
                'platform': platform or 'ملف مباشر',
                'type': 'video' if platform else 'file',
                'content_type': ct[:60] if ct else '—',
                'size': format_size(int(size)) if size else '—',
                'status': resp.status_code,
                'valid': True,
            })
        except:
            results.append({'url': url, 'domain': parsed.netloc,
                            'platform': platform or 'مجهول', 'valid': False,
                            'type': 'video' if platform else 'file'})
    return jsonify({'success': True, 'results': results})

@app.route('/api/batch-start', methods=['POST'])
@require_login
def batch_start():
    items = request.json.get('items', [])
    started = []
    for item in items[:5]:
        url = item.get('url','').strip()
        if not is_valid_url(url): continue
        itype = item.get('type','file')
        dl_id = hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()[:8]
        active_downloads[dl_id] = {'status':'في الانتظار...','progress':0,'url':url,'type':itype}
        if itype == 'video':
            quality = item.get('quality','720p')
            def do_vid(u=url, q=quality, did=dl_id):
                fmt = pick_format(q)
                safe_time = datetime.now().strftime('%Y%m%d_%H%M%S')
                ydl_opts = {
                    'format': fmt,
                    'outtmpl': os.path.join(VIDEOS_DIR, f'{safe_time}_%(title).60s.%(ext)s'),
                    'quiet': True,
                    'no_warnings': True,
                    'noplaylist': True,
                }
                if HAS_FFMPEG:
                    ydl_opts['postprocessors'] = [{'key': 'FFmpegVideoConvertor', 'preferedformat': 'mp4'}]
                    ydl_opts['merge_output_format'] = 'mp4'
                def ph(d):
                    if d['status']=='downloading':
                        raw=strip_ansi(d.get('_percent_str','0%')).strip().replace('%','')
                        try:
                            pct=float(raw)
                            active_downloads[did]['progress']=pct
                            active_downloads[did]['status']=f"تحميل {pct:.1f}%"
                        except: pass
                    elif d['status']=='finished':
                        active_downloads[did].update({'progress':99,'status':'معالجة...'})
                ydl_opts['progress_hooks']=[ph]
                try:
                    with yt_dlp.YoutubeDL(ydl_opts) as ydl: ydl.extract_info(u, download=True)
                    files = sorted(Path(VIDEOS_DIR).glob('*'), key=lambda f: f.stat().st_mtime, reverse=True)
                    if files:
                        fsize=os.path.getsize(str(files[0]))
                        stats['total_downloads']+=1; stats['video_downloads']+=1; stats['size_downloaded']+=fsize
                        active_downloads[did].update({'status':'تم ✅','progress':100,'done':True,'size':format_size(fsize),'filename':files[0].name})
                    else: active_downloads[did].update({'status':'فشل','error':True})
                except Exception as e: active_downloads[did].update({'status':f'خطأ: {strip_ansi(str(e))[:100]}','error':True})
            threading.Thread(target=do_vid, daemon=True).start()
        else:
            def do_file(u=url, did=dl_id):
                try:
                    headers={'User-Agent':'Mozilla/5.0'}
                    resp=requests.get(u,stream=True,headers=headers,timeout=30,allow_redirects=True)
                    parsed2=urlparse(resp.url)
                    fname=unquote(os.path.basename(parsed2.path)) or f'file_{datetime.now().strftime("%H%M%S")}'
                    fname=re.sub(r'[<>:"/\\|?*]','_',fname)
                    fpath=os.path.join(FILES_DIR,fname)
                    total=int(resp.headers.get('content-length',0)); downloaded=0
                    with open(fpath,'wb') as f:
                        for chunk in resp.iter_content(65536):
                            if chunk: f.write(chunk); downloaded+=len(chunk)
                            if total: active_downloads[did].update({'progress':(downloaded/total)*100,'status':f"تحميل {(downloaded/total)*100:.1f}%"})
                    fsize=os.path.getsize(fpath)
                    stats['total_downloads']+=1; stats['file_downloads']+=1; stats['size_downloaded']+=fsize
                    active_downloads[did].update({'status':'تم ✅','progress':100,'done':True,'filename':fname,'size':format_size(fsize)})
                except Exception as e: active_downloads[did].update({'status':f'خطأ: {str(e)[:100]}','error':True})
            threading.Thread(target=do_file, daemon=True).start()
        started.append({'id': dl_id, 'url': url})
    return jsonify({'success': True, 'started': started})


# ======================== RANDOM / FUN ========================
@app.route('/api/random-quote', methods=['GET'])
@require_login
def random_quote():
    try:
        r = requests.get('https://api.quotable.io/random?lang=en', timeout=6)
        d = r.json()
        return jsonify({'success': True, 'quote': d.get('content',''), 'author': d.get('author','')})
    except:
        quotes = [
            ('العقل السليم في الجسم السليم', 'مثل عربي'),
            ('المعرفة قوة', 'فرانسيس بيكون'),
            ('الوقت كالسيف إن لم تقطعه قطعك', 'مثل عربي'),
            ('فكر قبل أن تتكلم، واقرأ قبل أن تفكر', 'فراس ألفن'),
        ]
        import random
        q = random.choice(quotes)
        return jsonify({'success': True, 'quote': q[0], 'author': q[1]})

@app.route('/api/uuid', methods=['GET'])
@require_login
def gen_uuid():
    import uuid
    return jsonify({'uuid': str(uuid.uuid4()), 'uuid_simple': str(uuid.uuid4()).replace('-','')})

@app.route('/api/timestamp', methods=['GET'])
@require_login
def get_timestamp():
    now = datetime.now()
    import calendar
    return jsonify({
        'unix': int(time.time()),
        'unix_ms': int(time.time()*1000),
        'iso': now.isoformat(),
        'utc': datetime.utcnow().isoformat(),
        'date': now.strftime('%Y-%m-%d'),
        'time': now.strftime('%H:%M:%S'),
        'day': now.strftime('%A'),
        'week': now.isocalendar()[1],
    })


# ======================== PWA ========================
@app.route('/manifest.json')
def manifest():
    return jsonify({
        'name': 'مركز التحميل الذكي', 'short_name': 'التحميل الذكي',
        'start_url': '/', 'display': 'standalone', 'dir': 'rtl', 'lang': 'ar',
        'background_color': '#0d0d1a', 'theme_color': '#7c3aed',
        'icons': [{'src': '/static/icons/icon-192x192.png', 'sizes': '192x192', 'type': 'image/png'}],
    })

@app.route('/sw.js')
def service_worker():
    return Response("self.addEventListener('fetch',function(){});", mimetype='application/javascript')

@app.route('/static/icons/<name>')
def app_icon(name):
    m = re.search(r'(\d+)', name)
    size = int(m.group(1)) if m else 192
    size = max(16, min(size, 512))
    img = Image.new('RGB', (size, size), '#7c3aed')
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    p = size // 4
    d.polygon([(p, size*0.45), (size-p, size*0.45), (size/2, size*0.75)], fill='white')
    d.rectangle([size*0.43, p, size*0.57, size*0.5], fill='white')
    buf = io.BytesIO(); img.save(buf, format='PNG'); buf.seek(0)
    return send_file(buf, mimetype='image/png')

@app.route('/offline')
def offline():
    return render_template_string(OFFLINE_HTML)

def run_server(host='127.0.0.1', port=5000):
    """Entry point used by the Android launcher (blocks)."""
    from werkzeug.serving import make_server
    srv = make_server(host, port, app, threaded=True)
    srv.serve_forever()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
