import os


def start(downloads_dir, home_dir, port=5000):
    """Called from Kotlin (ServerService). Blocks while the Flask server runs."""
    os.environ['APP_DOWNLOADS_DIR'] = str(downloads_dir)
    os.environ['HOME'] = str(home_dir)
    os.environ.setdefault('XDG_CACHE_HOME', os.path.join(str(home_dir), 'cache'))
    os.makedirs(os.environ['XDG_CACHE_HOME'], exist_ok=True)
    import main1
    main1.run_server('127.0.0.1', int(port))
