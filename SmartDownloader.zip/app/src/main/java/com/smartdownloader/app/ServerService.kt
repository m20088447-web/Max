package com.smartdownloader.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

/**
 * Foreground service: keeps the process alive (so downloads continue in the
 * background) and runs the Flask server (main1.py) through Chaquopy.
 */
class ServerService : Service() {

    companion object {
        const val PORT = 5000

        @Volatile
        var running = false

        @Volatile
        var lastError: String? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("server", "الخادم المحلي", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, "server")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("مركز التحميل الذكي")
            .setContentText("الخدمة تعمل في الخلفية")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, notification)
        }

        startPython()
    }

    @Synchronized
    private fun startPython() {
        if (running) return
        running = true
        lastError = null

        Thread(null, {
            try {
                if (!Python.isStarted()) {
                    Python.start(AndroidPlatform(applicationContext))
                }
                val downloads = (getExternalFilesDir(null) ?: filesDir).resolve("downloads")
                downloads.mkdirs()
                Python.getInstance()
                    .getModule("android_main")
                    .callAttr("start", downloads.absolutePath, filesDir.absolutePath, PORT)
            } catch (t: Throwable) {
                lastError = t.toString()
                running = false
            }
        }, "flask-server", 8L * 1024 * 1024).start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
}
