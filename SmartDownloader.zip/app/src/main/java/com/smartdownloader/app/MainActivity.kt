package com.smartdownloader.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var loading: TextView
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var docStartScriptOk = false

    private val baseUrl = "http://127.0.0.1:${ServerService.PORT}"

    // Makes `Notification` work inside the WebView (forwards to a native notification)
    private val shimJs = """
        (function(){
          if (window.__shimDone) return; window.__shimDone = true;
          function N(title, opts){
            try { AndroidBridge.notify(String(title), String((opts && opts.body) || '')); } catch(e) {}
          }
          N.permission = 'granted';
          N.requestPermission = function(cb){ if (cb) cb('granted'); return Promise.resolve('granted'); };
          window.Notification = N;
        })();
    """.trimIndent()

    private val fileChooser = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        pendingFileCallback?.onReceiveValue(uris)
        pendingFileCallback = null
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNeededPermissions()
        ContextCompat.startForegroundService(this, Intent(this, ServerService::class.java))

        buildUi()
        setupWebView()
        waitForServerThenLoad()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0D0D1A"))

        webView = WebView(this)
        webView.setBackgroundColor(Color.parseColor("#0D0D1A"))
        root.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        loading = TextView(this).apply {
            text = "🚀\nجاري تشغيل الخادم المحلي...\n(قد يستغرق التشغيل الأول بضع ثوانٍ)"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 16f
            setBackgroundColor(Color.parseColor("#0D0D1A"))
        }
        root.addView(
            loading,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            setSupportZoom(false)
            textZoom = 100
        }
        CookieManager.getInstance().setAcceptCookie(true)

        webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        docStartScriptOk = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStartScriptOk) {
            WebViewCompat.addDocumentStartJavaScript(webView, shimJs, setOf(baseUrl))
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (!docStartScriptOk) view.evaluateJavascript(shimJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                loading.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host ?: ""
                if (host == "127.0.0.1" || host == "localhost") return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {
                    }
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                wv: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = callback
                return try {
                    fileChooser.launch(params!!.createIntent())
                    true
                } catch (e: Exception) {
                    pendingFileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            saveDownload(url, contentDisposition, mimeType)
        }
    }

    private fun waitForServerThenLoad() {
        Thread {
            val deadline = System.currentTimeMillis() + 120_000
            var ok = false
            while (System.currentTimeMillis() < deadline) {
                if (ServerService.lastError != null) break
                try {
                    Socket().use { it.connect(InetSocketAddress("127.0.0.1", ServerService.PORT), 500) }
                    ok = true
                    break
                } catch (e: Exception) {
                    Thread.sleep(500)
                }
            }
            runOnUiThread {
                if (ok) {
                    webView.loadUrl("$baseUrl/")
                } else {
                    loading.text = "تعذر تشغيل الخادم المحلي\n" + (ServerService.lastError ?: "انتهت المهلة")
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- bridge
    inner class Bridge {
        @JavascriptInterface
        fun notify(title: String, body: String) {
            showNotification(title, body)
        }
    }

    private fun showNotification(title: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("done", "اكتمال التحميل", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = Notification.Builder(this, "done")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt() + 100, n)
    }

    // ------------------------------------------------- save to public Downloads
    private fun saveDownload(url: String, contentDisposition: String?, mimeType: String?) {
        Thread {
            try {
                var conn: HttpURLConnection? = null
                val input: InputStream
                var type: String? = mimeType?.takeIf { it.isNotBlank() && it != "application/octet-stream" }
                var name: String? = Regex("""filename\*?=(?:UTF-8'')?"?([^";]+)"?""", RegexOption.IGNORE_CASE)
                    .find(contentDisposition ?: "")?.groupValues?.get(1)?.let { Uri.decode(it) }

                if (url.startsWith("data:")) {
                    val comma = url.indexOf(',')
                    val header = url.substring(5, comma)
                    val data = url.substring(comma + 1)
                    val bytes = if (header.contains(";base64"))
                        Base64.decode(data, Base64.DEFAULT) else Uri.decode(data).toByteArray()
                    if (type == null) type = header.substringBefore(';').ifBlank { "application/octet-stream" }
                    if (name == null) {
                        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(type) ?: "bin"
                        name = "download_${System.currentTimeMillis()}.$ext"
                    }
                    input = bytes.inputStream()
                } else {
                    conn = URL(url).openConnection() as HttpURLConnection
                    CookieManager.getInstance().getCookie(url)?.let { conn.setRequestProperty("Cookie", it) }
                    conn.connectTimeout = 15000
                    conn.connect()
                    if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
                    if (name == null) {
                        val last = Uri.decode(url.substringBefore('?').substringAfterLast('/'))
                        name = last.ifBlank { URLUtil.guessFileName(url, contentDisposition, mimeType) }
                    }
                    if (type == null) type = conn.contentType?.substringBefore(';')
                    input = conn.inputStream
                }

                val safeName = (name ?: "download_${System.currentTimeMillis()}")
                    .replace(Regex("""[\\/:*?"<>|]"""), "_")
                val ext = safeName.substringAfterLast('.', "").lowercase()
                val finalType = type?.takeIf { it.isNotBlank() }
                    ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    ?: "application/octet-stream"

                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, finalType)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SmartDownloader")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw Exception("MediaStore insert failed")
                    contentResolver.openOutputStream(uri)!!.use { out -> input.use { it.copyTo(out) } }
                } else {
                    val dir = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        "SmartDownloader"
                    )
                    dir.mkdirs()
                    File(dir, safeName).outputStream().use { out -> input.use { it.copyTo(out) } }
                }
                conn?.disconnect()

                runOnUiThread {
                    Toast.makeText(this, "✅ تم الحفظ في التنزيلات/SmartDownloader\n$safeName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "❌ فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ----------------------------------------------------------- permissions
    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28) needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
